import api from "./api";

export const productApi = {
  list: () => api.get("/products"),
  lowStock: () => api.get("/products/low-stock"),
  create: (payload) => api.post("/products", payload),
  update: (id, payload) => api.put(`/products/${id}`, payload),
  remove: (id) => api.delete(`/products/${id}`),
};

export const inventoryApi = {
  stockIn: (productId, quantity, note) => api.post("/inventory/stock-in", { productId, quantity, note }),
  stockOut: (productId, quantity, note) => api.post("/inventory/stock-out", { productId, quantity, note }),
  adjust: (productId, quantity, note) => api.post("/inventory/adjust", { productId, quantity, note }),
  history: (productId) => api.get(`/inventory/history/${productId}`),
};

export const customerApi = {
  list: (search) => api.get(`/customers${search ? `?search=${encodeURIComponent(search)}` : ""}`),
  create: (payload) => api.post("/customers", payload),
  get: (id) => api.get(`/customers/${id}`),
  update: (id, payload) => api.put(`/customers/${id}`, payload),
  remove: (id) => api.delete(`/customers/${id}`),
};

export const invoiceApi = {
  list: () => api.get("/invoices"),
  get: (id) => api.get(`/invoices/${id}`),
  create: (payload) => api.post("/invoices", payload),
  cancel: (id) => api.post(`/invoices/${id}/cancel`),
};

export const transactionApi = {
  list: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return api.get(`/transactions${qs ? `?${qs}` : ""}`);
  },
  create: (payload) => api.post("/transactions", payload),
  remove: (id) => api.delete(`/transactions/${id}`),
};

export const ledgerApi = {
  summary: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return api.get(`/ledger/summary${qs ? `?${qs}` : ""}`);
  },
  growth: (days) => api.get(`/ledger/growth${days ? `?days=${days}` : ""}`),
  inventorySnapshot: () => api.get("/ledger/inventory-snapshot"),
};
