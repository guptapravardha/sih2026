/* ===========================================================
   BILLING — the actual bill-creation transaction, extracted so
   it can be unit-tested directly (see tests/billing.test.js)
   without going through HTTP.
   =========================================================== */

class BillingError extends Error {}

/**
 * Creates an invoice: validates stock for every line item, computes
 * subtotal/discount/total, writes the invoice + items, deducts stock,
 * logs inventory history, and records a revenue transaction — all in
 * one atomic SQLite transaction. Throws BillingError on any problem,
 * which rolls the whole transaction back (nothing partial is saved).
 */
function createInvoice(db, userId, { customerId, customerName, discount = 0, items }) {
  if (!items || items.length === 0) {
    throw new BillingError("An invoice needs at least one item");
  }

  const run = db.transaction(() => {
    let subtotal = 0;
    const resolvedItems = items.map((item) => {
      if (!(item.quantity > 0)) {
        throw new BillingError("Quantity must be greater than zero");
      }
      const product = db
        .prepare("SELECT * FROM products WHERE id = ? AND user_id = ? AND is_active = 1")
        .get(item.productId, userId);
      if (!product) {
        throw new BillingError(`Product not found: ${item.productId}`);
      }
      if (item.quantity > product.current_stock) {
        throw new BillingError(
          `Not enough stock for ${product.name} (have ${product.current_stock}, need ${item.quantity})`
        );
      }
      const lineTotal = product.selling_price * item.quantity;
      subtotal += lineTotal;
      return { product, quantity: item.quantity, lineTotal };
    });

    const clampedDiscount = Math.min(Math.max(discount, 0), subtotal);
    const totalAmount = subtotal - clampedDiscount;

    const invoiceInfo = db
      .prepare(
        `INSERT INTO invoices (user_id, customer_id, customer_name, subtotal, discount, total_amount, payment_status)
         VALUES (?, ?, ?, ?, ?, ?, 'paid')`
      )
      .run(userId, customerId || null, customerName || null, subtotal, clampedDiscount, totalAmount);
    const invoiceId = invoiceInfo.lastInsertRowid;

    for (const { product, quantity, lineTotal } of resolvedItems) {
      db.prepare(
        `INSERT INTO invoice_items (invoice_id, product_id, product_name, quantity, selling_price, total)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(invoiceId, product.id, product.name, quantity, product.selling_price, lineTotal);

      const newStock = product.current_stock - quantity;
      db.prepare("UPDATE products SET current_stock = ?, updated_at = datetime('now') WHERE id = ?").run(
        newStock,
        product.id
      );

      db.prepare(
        `INSERT INTO inventory_history (product_id, user_id, change_type, quantity_change, resulting_stock, note, reference_type, reference_id)
         VALUES (?, ?, 'sale', ?, ?, ?, 'invoice', ?)`
      ).run(product.id, userId, -quantity, newStock, `Sold via invoice #${invoiceId}`, invoiceId);
    }

    db.prepare(
      `INSERT INTO transactions (user_id, type, amount, description, reference_type, reference_id)
       VALUES (?, 'sale', ?, ?, 'invoice', ?)`
    ).run(userId, totalAmount, `Invoice #${invoiceId}${customerName ? " — " + customerName : ""}`, invoiceId);

    return { invoiceId, subtotal, discount: clampedDiscount, totalAmount };
  });

  return run();
}

module.exports = { createInvoice, BillingError };
