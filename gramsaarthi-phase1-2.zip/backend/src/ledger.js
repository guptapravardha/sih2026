/* ===========================================================
   LEDGER ENGINE — deterministic bookkeeping calculations.
   Reads only from the `transactions` table (populated by real
   invoices and manual entries). No AI/LLM touches these numbers.
   =========================================================== */

const db = require("./db");

const REVENUE_TYPES = ["sale", "income"];
const EXPENSE_TYPES = ["expense", "purchase"];

function sumByType(userId, types, from, to) {
  const placeholders = types.map(() => "?").join(",");
  let sql = `SELECT COALESCE(SUM(amount), 0) as total FROM transactions
             WHERE user_id = ? AND type IN (${placeholders})`;
  const params = [userId, ...types];
  if (from) {
    sql += " AND created_at >= ?";
    params.push(from);
  }
  if (to) {
    sql += " AND created_at <= ?";
    params.push(to);
  }
  return db.prepare(sql).get(...params).total;
}

/**
 * Revenue = sum of 'sale' + 'income' transactions in the window.
 * Expenses = sum of 'expense' + 'purchase' transactions in the window.
 * Profit = Revenue - Expenses.
 * Profit Margin = (Profit / Revenue) * 100, safely handling Revenue = 0.
 */
function financialSummary(userId, { from, to } = {}) {
  const revenue = sumByType(userId, REVENUE_TYPES, from, to);
  const expenses = sumByType(userId, EXPENSE_TYPES, from, to);
  const profit = revenue - expenses;
  const profitMargin = revenue > 0 ? (profit / revenue) * 100 : 0;

  const transactionCount = db
    .prepare(
      `SELECT COUNT(*) c FROM transactions WHERE user_id = ?
       ${from ? "AND created_at >= ?" : ""} ${to ? "AND created_at <= ?" : ""}`
    )
    .get(...[userId, ...(from ? [from] : []), ...(to ? [to] : [])]).c;

  return {
    revenue,
    expenses,
    profit,
    profitMargin: Math.round(profitMargin * 10) / 10,
    transactionCount,
    window: { from: from || null, to: to || null },
  };
}

/**
 * Growth % for the given period, comparing the current period's revenue
 * against the immediately preceding period of the same length.
 * Growth % = ((Current - Previous) / Previous) * 100
 * Returns null components (not a fabricated 0%) when there isn't enough
 * history to compute a meaningful comparison.
 */
function revenueGrowth(userId, periodDays = 30) {
  const now = new Date();
  const periodMs = periodDays * 24 * 60 * 60 * 1000;

  const currentFrom = new Date(now.getTime() - periodMs).toISOString();
  const currentTo = now.toISOString();
  const previousFrom = new Date(now.getTime() - 2 * periodMs).toISOString();
  const previousTo = currentFrom;

  const currentRevenue = sumByType(userId, REVENUE_TYPES, currentFrom, currentTo);
  const previousRevenue = sumByType(userId, REVENUE_TYPES, previousFrom, previousTo);

  const earliestTx = db
    .prepare("SELECT MIN(created_at) as earliest FROM transactions WHERE user_id = ?")
    .get(userId).earliest;

  const hasEnoughHistory = earliestTx && new Date(earliestTx) <= new Date(previousFrom);

  if (!hasEnoughHistory) {
    return {
      growthPercentage: null,
      direction: null,
      period: `${periodDays}d`,
      currentRevenue,
      previousRevenue,
      dataCompleteness: { sufficient: false, reason: "Not enough transaction history yet to compare periods." },
    };
  }

  let growthPercentage;
  if (previousRevenue === 0) {
    growthPercentage = currentRevenue > 0 ? 100 : 0;
  } else {
    growthPercentage = ((currentRevenue - previousRevenue) / previousRevenue) * 100;
  }

  return {
    growthPercentage: Math.round(growthPercentage * 10) / 10,
    direction: growthPercentage > 0 ? "up" : growthPercentage < 0 ? "down" : "flat",
    period: `${periodDays}d`,
    currentRevenue,
    previousRevenue,
    dataCompleteness: { sufficient: true },
  };
}

module.exports = { financialSummary, revenueGrowth, REVENUE_TYPES, EXPENSE_TYPES };
