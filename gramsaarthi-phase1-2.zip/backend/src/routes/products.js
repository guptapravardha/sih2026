const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");

const router = express.Router();
router.use(requireAuth);

const productSchema = z.object({
  name: z.string().min(1).max(150),
  category: z.string().max(100).optional().nullable(),
  costPrice: z.number().min(0),
  sellingPrice: z.number().min(0),
  currentStock: z.number().min(0),
  reorderLevel: z.number().min(0).default(0),
  businessId: z.number().int().optional().nullable(),
});

function loadOwnedProduct(userId, id) {
  return db.prepare("SELECT * FROM products WHERE id = ? AND user_id = ?").get(id, userId);
}

// LIST
router.get("/", (req, res) => {
  const products = db
    .prepare("SELECT * FROM products WHERE user_id = ? AND is_active = 1 ORDER BY name ASC")
    .all(req.user.id);
  res.json({ products });
});

// LOW STOCK
router.get("/low-stock", (req, res) => {
  const products = db
    .prepare(
      "SELECT * FROM products WHERE user_id = ? AND is_active = 1 AND current_stock <= reorder_level ORDER BY current_stock ASC"
    )
    .all(req.user.id);
  res.json({ products });
});

// CREATE
router.post("/", (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const p = parsed.data;

  const info = db
    .prepare(
      `INSERT INTO products (user_id, business_id, name, category, cost_price, selling_price, current_stock, reorder_level)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.user.id, p.businessId || null, p.name, p.category || null, p.costPrice, p.sellingPrice, p.currentStock, p.reorderLevel);

  if (p.currentStock > 0) {
    db.prepare(
      `INSERT INTO inventory_history (product_id, user_id, change_type, quantity_change, resulting_stock, note)
       VALUES (?, ?, 'stock_in', ?, ?, 'Initial stock on product creation')`
    ).run(info.lastInsertRowid, req.user.id, p.currentStock, p.currentStock);
  }

  const product = loadOwnedProduct(req.user.id, info.lastInsertRowid);
  res.status(201).json({ product });
});

// UPDATE (details only — use /inventory routes to change stock so history stays accurate)
router.put("/:id", (req, res) => {
  const existing = loadOwnedProduct(req.user.id, req.params.id);
  if (!existing) return res.status(404).json({ error: "Product not found" });

  const parsed = productSchema.partial({ currentStock: true }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const p = parsed.data;

  db.prepare(
    `UPDATE products SET
       name = COALESCE(?, name),
       category = ?,
       cost_price = COALESCE(?, cost_price),
       selling_price = COALESCE(?, selling_price),
       reorder_level = COALESCE(?, reorder_level),
       updated_at = datetime('now')
     WHERE id = ? AND user_id = ?`
  ).run(
    p.name ?? null,
    p.category !== undefined ? p.category : existing.category,
    p.costPrice ?? null,
    p.sellingPrice ?? null,
    p.reorderLevel ?? null,
    req.params.id,
    req.user.id
  );

  res.json({ product: loadOwnedProduct(req.user.id, req.params.id) });
});

// DELETE (soft delete — preserves invoice/history integrity)
router.delete("/:id", (req, res) => {
  const existing = loadOwnedProduct(req.user.id, req.params.id);
  if (!existing) return res.status(404).json({ error: "Product not found" });

  db.prepare("UPDATE products SET is_active = 0, updated_at = datetime('now') WHERE id = ? AND user_id = ?").run(
    req.params.id,
    req.user.id
  );
  res.json({ ok: true });
});

module.exports = router;
