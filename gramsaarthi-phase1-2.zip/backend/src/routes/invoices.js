const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");
const { createInvoice, BillingError } = require("../billing");

const router = express.Router();
router.use(requireAuth);

const itemSchema = z.object({
  productId: z.number().int(),
  quantity: z.number().positive(),
});

const invoiceSchema = z.object({
  customerId: z.number().int().optional().nullable(),
  customerName: z.string().max(150).optional().nullable(),
  discount: z.number().min(0).default(0),
  items: z.array(itemSchema).min(1, "An invoice needs at least one item"),
});

// LIST
router.get("/", (req, res) => {
  const invoices = db
    .prepare("SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC")
    .all(req.user.id);
  res.json({ invoices });
});

// DETAIL (with line items)
router.get("/:id", (req, res) => {
  const invoice = db.prepare("SELECT * FROM invoices WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!invoice) return res.status(404).json({ error: "Invoice not found" });
  const items = db.prepare("SELECT * FROM invoice_items WHERE invoice_id = ?").all(invoice.id);
  res.json({ invoice, items });
});

// CREATE — this is the "stock 50, invoice qty 3 -> stock 47, and it survives a restart" test.
router.post("/", (req, res) => {
  const parsed = invoiceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { customerId, customerName, discount, items } = parsed.data;
  const userId = req.user.id;

  try {
    const result = createInvoice(db, userId, { customerId, customerName, discount, items });
    const invoice = db.prepare("SELECT * FROM invoices WHERE id = ?").get(result.invoiceId);
    const savedItems = db.prepare("SELECT * FROM invoice_items WHERE invoice_id = ?").all(result.invoiceId);
    res.status(201).json({ invoice, items: savedItems });
  } catch (err) {
    // better-sqlite3 rolls the whole transaction back automatically on a thrown error,
    // so no partial invoice, no partial stock deduction ever lands in the database.
    const status = err instanceof BillingError ? 400 : 500;
    res.status(status).json({ error: err.message || "Failed to create invoice" });
  }
});

// CANCEL — restores stock and reverses the revenue transaction, also atomically.
router.post("/:id/cancel", (req, res) => {
  const userId = req.user.id;
  const invoice = db.prepare("SELECT * FROM invoices WHERE id = ? AND user_id = ?").get(req.params.id, userId);
  if (!invoice) return res.status(404).json({ error: "Invoice not found" });
  if (invoice.payment_status === "cancelled") return res.status(400).json({ error: "Invoice already cancelled" });

  const run = db.transaction(() => {
    const items = db.prepare("SELECT * FROM invoice_items WHERE invoice_id = ?").all(invoice.id);
    for (const item of items) {
      const product = db.prepare("SELECT * FROM products WHERE id = ?").get(item.product_id);
      if (!product) continue; // product may have been hard-deleted; stock restore not possible
      const newStock = product.current_stock + item.quantity;
      db.prepare("UPDATE products SET current_stock = ?, updated_at = datetime('now') WHERE id = ?").run(
        newStock,
        product.id
      );
      db.prepare(
        `INSERT INTO inventory_history (product_id, user_id, change_type, quantity_change, resulting_stock, note, reference_type, reference_id)
         VALUES (?, ?, 'stock_in', ?, ?, ?, 'invoice_cancel', ?)`
      ).run(product.id, userId, item.quantity, newStock, `Restored from cancelled invoice #${invoice.id}`, invoice.id);
    }

    db.prepare("UPDATE invoices SET payment_status = 'cancelled' WHERE id = ?").run(invoice.id);

    db.prepare(
      `INSERT INTO transactions (user_id, type, amount, description, reference_type, reference_id)
       VALUES (?, 'refund', ?, ?, 'invoice', ?)`
    ).run(userId, invoice.total_amount, `Cancelled invoice #${invoice.id}`, invoice.id);
  });
  run();

  res.json({ ok: true });
});

module.exports = router;
