const express = require("express");
const db = require("../db");
const { requireAuth } = require("../auth");
const { financialSummary, revenueGrowth } = require("../ledger");

const router = express.Router();
router.use(requireAuth);

// Overall financial summary from real recorded transactions.
router.get("/summary", (req, res) => {
  const { from, to } = req.query;
  res.json(financialSummary(req.user.id, { from, to }));
});

// Revenue growth vs. the prior period of the same length.
router.get("/growth", (req, res) => {
  const days = Number(req.query.days) || 30;
  res.json(revenueGrowth(req.user.id, days));
});

// Low-stock + basic inventory value snapshot, useful for the dashboard.
router.get("/inventory-snapshot", (req, res) => {
  const products = db.prepare("SELECT * FROM products WHERE user_id = ? AND is_active = 1").all(req.user.id);
  const totalStockValue = products.reduce((sum, p) => sum + p.current_stock * p.cost_price, 0);
  const lowStock = products.filter((p) => p.current_stock <= p.reorder_level);
  res.json({
    totalProducts: products.length,
    totalStockValue,
    lowStockCount: lowStock.length,
    lowStock,
  });
});

module.exports = router;
