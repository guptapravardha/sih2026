const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");

const router = express.Router();
router.use(requireAuth);

const MANUAL_TYPES = ["income", "expense", "purchase", "payment"];

const txSchema = z.object({
  type: z.enum(MANUAL_TYPES),
  amount: z.number().positive(),
  description: z.string().max(300).optional().nullable(),
});

// LIST — optional ?from=&to= (ISO date strings) and ?type=
router.get("/", (req, res) => {
  const { from, to, type } = req.query;
  let sql = "SELECT * FROM transactions WHERE user_id = ?";
  const params = [req.user.id];

  if (from) {
    sql += " AND created_at >= ?";
    params.push(from);
  }
  if (to) {
    sql += " AND created_at <= ?";
    params.push(to);
  }
  if (type) {
    sql += " AND type = ?";
    params.push(type);
  }
  sql += " ORDER BY created_at DESC LIMIT 500";

  const transactions = db.prepare(sql).all(...params);
  res.json({ transactions });
});

// CREATE — for manual entries only. Sales are written by POST /api/invoices, not here,
// so revenue always has a real invoice behind it.
router.post("/", (req, res) => {
  const parsed = txSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { type, amount, description } = parsed.data;

  const info = db
    .prepare("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)")
    .run(req.user.id, type, amount, description || null);

  const transaction = db.prepare("SELECT * FROM transactions WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ transaction });
});

router.delete("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM transactions WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: "Transaction not found" });
  if (existing.reference_type) {
    return res.status(400).json({
      error: "This transaction was generated automatically (e.g. from an invoice) and can't be deleted directly.",
    });
  }
  db.prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?").run(req.params.id, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
