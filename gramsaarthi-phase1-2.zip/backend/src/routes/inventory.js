const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");

const router = express.Router();
router.use(requireAuth);

function loadOwnedProduct(userId, id) {
  return db.prepare("SELECT * FROM products WHERE id = ? AND user_id = ?").get(id, userId);
}

const adjustSchema = z.object({
  productId: z.number().int(),
  quantity: z.number(), // positive number; direction comes from the endpoint used
  note: z.string().max(300).optional().nullable(),
});

function applyAdjustment(req, res, changeType, signedQuantity) {
  const parsed = adjustSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { productId, quantity, note } = parsed.data;

  if (quantity <= 0) return res.status(400).json({ error: "Quantity must be greater than zero" });

  const product = loadOwnedProduct(req.user.id, productId);
  if (!product) return res.status(404).json({ error: "Product not found" });

  const delta = signedQuantity < 0 ? -quantity : quantity;
  const newStock = product.current_stock + delta;

  if (newStock < 0) {
    return res.status(400).json({
      error: `Not enough stock: ${product.name} has ${product.current_stock} in stock, cannot remove ${quantity}`,
    });
  }

  const run = db.transaction(() => {
    db.prepare("UPDATE products SET current_stock = ?, updated_at = datetime('now') WHERE id = ?").run(
      newStock,
      productId
    );
    db.prepare(
      `INSERT INTO inventory_history (product_id, user_id, change_type, quantity_change, resulting_stock, note)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(productId, req.user.id, changeType, delta, newStock, note || null);
  });
  run();

  res.json({ product: loadOwnedProduct(req.user.id, productId) });
}

// STOCK IN
router.post("/stock-in", (req, res) => applyAdjustment(req, res, "stock_in", +1));

// STOCK OUT (manual removal, not a sale — sales go through /api/invoices)
router.post("/stock-out", (req, res) => applyAdjustment(req, res, "stock_out", -1));

// ADJUSTMENT (correction — `quantity` may be positive (add) or negative (remove); we pass its magnitude through)
router.post("/adjust", (req, res) => {
  const parsed = z
    .object({ productId: z.number().int(), quantity: z.number().refine((v) => v !== 0), note: z.string().max(300).optional().nullable() })
    .safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const { productId, quantity, note } = parsed.data;
  const direction = quantity >= 0 ? +1 : -1;
  req.body = { productId, quantity: Math.abs(quantity), note };
  return applyAdjustment(req, res, "adjustment", direction);
});

// HISTORY for one product
router.get("/history/:productId", (req, res) => {
  const product = loadOwnedProduct(req.user.id, req.params.productId);
  if (!product) return res.status(404).json({ error: "Product not found" });

  const history = db
    .prepare("SELECT * FROM inventory_history WHERE product_id = ? ORDER BY created_at DESC LIMIT 200")
    .all(req.params.productId);
  res.json({ history });
});

module.exports = router;
