const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");

const router = express.Router();
router.use(requireAuth);

const customerSchema = z.object({
  name: z.string().min(1).max(150),
  phone: z.string().max(30).optional().nullable(),
  email: z.string().email().optional().nullable().or(z.literal("")),
  notes: z.string().max(500).optional().nullable(),
});

function loadOwnedCustomer(userId, id) {
  return db.prepare("SELECT * FROM customers WHERE id = ? AND user_id = ?").get(id, userId);
}

router.get("/", (req, res) => {
  const search = (req.query.search || "").trim();
  const customers = search
    ? db
        .prepare("SELECT * FROM customers WHERE user_id = ? AND name LIKE ? ORDER BY name ASC")
        .all(req.user.id, `%${search}%`)
    : db.prepare("SELECT * FROM customers WHERE user_id = ? ORDER BY name ASC").all(req.user.id);
  res.json({ customers });
});

router.post("/", (req, res) => {
  const parsed = customerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const c = parsed.data;

  const info = db
    .prepare("INSERT INTO customers (user_id, name, phone, email, notes) VALUES (?, ?, ?, ?, ?)")
    .run(req.user.id, c.name, c.phone || null, c.email || null, c.notes || null);

  res.status(201).json({ customer: loadOwnedCustomer(req.user.id, info.lastInsertRowid) });
});

router.get("/:id", (req, res) => {
  const customer = loadOwnedCustomer(req.user.id, req.params.id);
  if (!customer) return res.status(404).json({ error: "Customer not found" });

  const invoices = db
    .prepare("SELECT * FROM invoices WHERE user_id = ? AND customer_id = ? ORDER BY created_at DESC")
    .all(req.user.id, req.params.id);

  res.json({ customer, invoices });
});

router.put("/:id", (req, res) => {
  const existing = loadOwnedCustomer(req.user.id, req.params.id);
  if (!existing) return res.status(404).json({ error: "Customer not found" });

  const parsed = customerSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const c = parsed.data;

  db.prepare(
    `UPDATE customers SET
       name = COALESCE(?, name),
       phone = ?,
       email = ?,
       notes = ?,
       updated_at = datetime('now')
     WHERE id = ? AND user_id = ?`
  ).run(
    c.name ?? null,
    c.phone !== undefined ? c.phone : existing.phone,
    c.email !== undefined ? c.email : existing.email,
    c.notes !== undefined ? c.notes : existing.notes,
    req.params.id,
    req.user.id
  );

  res.json({ customer: loadOwnedCustomer(req.user.id, req.params.id) });
});

router.delete("/:id", (req, res) => {
  const existing = loadOwnedCustomer(req.user.id, req.params.id);
  if (!existing) return res.status(404).json({ error: "Customer not found" });
  db.prepare("DELETE FROM customers WHERE id = ? AND user_id = ?").run(req.params.id, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
