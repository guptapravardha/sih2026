/**
 * Run with:  cd backend && npm test
 * Uses a throwaway SQLite file (deleted after the run) so this never
 * touches your real gramsaarthi.db.
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");

const TEST_DB_PATH = path.join(__dirname, "__test.db");
process.env.DATABASE_FILE = TEST_DB_PATH;

function freshDb() {
  // Force a brand-new require of db.js against the test DB file each run.
  delete require.cache[require.resolve("../src/db")];
  if (fs.existsSync(TEST_DB_PATH)) fs.unlinkSync(TEST_DB_PATH);
  for (const ext of ["-wal", "-shm"]) {
    if (fs.existsSync(TEST_DB_PATH + ext)) fs.unlinkSync(TEST_DB_PATH + ext);
  }
  return require("../src/db");
}

function makeUser(db, email = "test@example.com") {
  const info = db
    .prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, 'x')")
    .run("Test User", email);
  return info.lastInsertRowid;
}

function makeProduct(db, userId, overrides = {}) {
  const p = {
    name: "Milk (1L)",
    category: "dairy",
    cost_price: 30,
    selling_price: 45,
    current_stock: 50,
    reorder_level: 10,
    ...overrides,
  };
  const info = db
    .prepare(
      `INSERT INTO products (user_id, name, category, cost_price, selling_price, current_stock, reorder_level)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(userId, p.name, p.category, p.cost_price, p.selling_price, p.current_stock, p.reorder_level);
  return info.lastInsertRowid;
}

test("invoice creation deducts stock correctly (50 - 3 = 47) and it survives a reload", () => {
  const db = freshDb();
  const { createInvoice } = require("../src/billing");

  const userId = makeUser(db);
  const productId = makeProduct(db, userId, { current_stock: 50 });

  const result = createInvoice(db, userId, {
    customerName: "Ramesh",
    discount: 0,
    items: [{ productId, quantity: 3 }],
  });

  assert.equal(result.subtotal, 135); // 45 * 3
  assert.equal(result.totalAmount, 135);

  let product = db.prepare("SELECT * FROM products WHERE id = ?").get(productId);
  assert.equal(product.current_stock, 47);

  // Simulate a restart: close and re-open the same DB file.
  db.close();
  const db2 = freshDbReopenOnly();
  product = db2.prepare("SELECT * FROM products WHERE id = ?").get(productId);
  assert.equal(product.current_stock, 47, "stock must persist across a restart, not reset");
  db2.close();
});

function freshDbReopenOnly() {
  delete require.cache[require.resolve("../src/db")];
  return require("../src/db");
}

test("invoice creation rejects and rolls back when stock is insufficient", () => {
  const db = freshDb();
  const { createInvoice, BillingError } = require("../src/billing");

  const userId = makeUser(db);
  const productId = makeProduct(db, userId, { current_stock: 5 });

  assert.throws(
    () =>
      createInvoice(db, userId, {
        customerName: "Ramesh",
        discount: 0,
        items: [{ productId, quantity: 10 }],
      }),
    BillingError
  );

  // Stock must be untouched — the whole transaction rolled back.
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(productId);
  assert.equal(product.current_stock, 5);

  const invoiceCount = db.prepare("SELECT COUNT(*) c FROM invoices").get().c;
  assert.equal(invoiceCount, 0, "no partial invoice should be saved");
});

test("discount is clamped to subtotal (never negative total)", () => {
  const db = freshDb();
  const { createInvoice } = require("../src/billing");

  const userId = makeUser(db);
  const productId = makeProduct(db, userId, { selling_price: 45, current_stock: 10 });

  const result = createInvoice(db, userId, {
    discount: 1000, // way more than the subtotal
    items: [{ productId, quantity: 2 }], // subtotal = 90
  });

  assert.equal(result.subtotal, 90);
  assert.equal(result.discount, 90); // clamped
  assert.equal(result.totalAmount, 0);
});

test("financial summary: revenue, expenses, profit, margin from real transactions", () => {
  const db = freshDb();
  const { financialSummary } = require("../src/ledger");
  const userId = makeUser(db);

  db.prepare("INSERT INTO transactions (user_id, type, amount) VALUES (?, 'sale', 100000)").run(userId);
  db.prepare("INSERT INTO transactions (user_id, type, amount) VALUES (?, 'expense', 70000)").run(userId);

  const summary = financialSummary(userId);
  assert.equal(summary.revenue, 100000);
  assert.equal(summary.expenses, 70000);
  assert.equal(summary.profit, 30000);
  assert.equal(summary.profitMargin, 30);
});

test("financial summary handles zero revenue safely (no divide-by-zero)", () => {
  const db = freshDb();
  const { financialSummary } = require("../src/ledger");
  const userId = makeUser(db);

  db.prepare("INSERT INTO transactions (user_id, type, amount) VALUES (?, 'expense', 5000)").run(userId);

  const summary = financialSummary(userId);
  assert.equal(summary.revenue, 0);
  assert.equal(summary.profit, -5000);
  assert.equal(summary.profitMargin, 0);
});

test("revenue growth reports insufficient data instead of a fabricated percentage", () => {
  const db = freshDb();
  const { revenueGrowth } = require("../src/ledger");
  const userId = makeUser(db);

  db.prepare("INSERT INTO transactions (user_id, type, amount) VALUES (?, 'sale', 1000)").run(userId);

  const growth = revenueGrowth(userId, 30);
  assert.equal(growth.growthPercentage, null);
  assert.equal(growth.dataCompleteness.sufficient, false);
});

test.after(() => {
  for (const ext of ["", "-wal", "-shm"]) {
    if (fs.existsSync(TEST_DB_PATH + ext)) fs.unlinkSync(TEST_DB_PATH + ext);
  }
});
