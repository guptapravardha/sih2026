# GramSaarthi — Unified Project (Phase 1 + Phase 2)

Merge of three source repos into one product:

- **frontend/** — SIH26S React/Vite UI (master frontend), wired to a real backend
- **backend/** — GramSaarthi Express + SQLite API, extended with a real Business Manager ledger

## Phase 1 (done previously) — Auth & i18n

- Real signup/login (bcrypt + JWT), session restore, backend-enforced route protection
- Real English/Hindi/Hinglish i18n, no hardcoded strings, no leakage
- Real API client with JWT injection and error surfacing

## Phase 2 (this delivery) — Business Manager port

Ported from `Buisness-Manager-main` (Java/MySQL) into the Node/SQLite backend, scoped per-user
(the original Java app was single-tenant; this one is multi-tenant so one entrepreneur can never
see another's stock, customers or invoices):

- **Products** — CRUD, soft delete, low-stock query (`backend/src/routes/products.js`)
- **Inventory** — stock-in / stock-out / manual adjustment, every change logged to
  `inventory_history` (`backend/src/routes/inventory.js`)
- **Customers** — CRUD + per-customer invoice history (`backend/src/routes/customers.js`)
- **Invoices/Billing** — `backend/src/billing.js` is a direct port of `BillingRepository.createBill`:
  checks stock for every line item first, computes subtotal, clamps discount to the subtotal,
  then atomically (one SQLite transaction) writes the invoice, writes line items, deducts stock,
  logs inventory history, and records a `sale` transaction. Any failure rolls back the *entire*
  transaction — no partial invoice, no partial stock deduction.
- **Transactions** — manual income/expense entries; sales are written automatically by invoices,
  never entered twice.
- **Ledger engine** (`backend/src/ledger.js`) — deterministic revenue/expense/profit/margin/growth,
  computed only from the `transactions` table. No LLM touches these numbers. Growth returns
  `null`/`"insufficient data"` rather than a fabricated percentage when there isn't enough history.

### The exact test from the spec

`backend/tests/billing.test.js` (Node's built-in test runner, no extra dependency) verifies:
- stock 50 → invoice qty 3 → stock 47, **and it survives closing and reopening the DB file**
- an over-quantity invoice is rejected and **fully rolled back** (zero stock change, zero invoice rows)
- discount is clamped to the subtotal (total is never negative)
- revenue/expenses/profit/margin match the spec's worked example (100000 / 70000 → 30000 profit, 30% margin)
- profit margin is 0 (not `Infinity`/`NaN`) when revenue is 0
- growth reports "insufficient data" instead of inventing a percentage when there's no prior period to compare

Run it with `cd backend && npm test`.

## Known limitation of this sandbox (unchanged from Phase 1)

I still have no outbound network access in this container — `npm install` is blocked even for
individual packages like `bcryptjs`. So:
- Every backend file passes `node --check` (no syntax errors).
- The test file above is real and will run once you `npm install` locally — I have not been able
  to execute it myself to show you a passing run. If it fails on your machine, send me the exact
  output and I'll fix the source.

## Run it locally

```powershell
# Backend
cd backend
copy .env.example .env      # then edit AUTH_SECRET at minimum
npm install
npm test                    # run the real billing/ledger tests
npm run seed                # optional demo data
npm run dev                 # http://localhost:4000

# Frontend (new terminal)
cd frontend
copy .env.example .env
npm install
npm run dev                 # http://localhost:5173
```

New endpoints added this phase (all under `/api`, all require a JWT via `requireAuth`):

```
GET    /api/products
GET    /api/products/low-stock
POST   /api/products
PUT    /api/products/:id
DELETE /api/products/:id            (soft delete)

POST   /api/inventory/stock-in
POST   /api/inventory/stock-out
POST   /api/inventory/adjust
GET    /api/inventory/history/:productId

GET    /api/customers
POST   /api/customers
GET    /api/customers/:id           (includes their invoice history)
PUT    /api/customers/:id
DELETE /api/customers/:id

GET    /api/invoices
GET    /api/invoices/:id
POST   /api/invoices                (the stock-deduction transaction)
POST   /api/invoices/:id/cancel     (restores stock, reverses the revenue transaction)

GET    /api/transactions
POST   /api/transactions            (manual income/expense only)
DELETE /api/transactions/:id

GET    /api/ledger/summary          (revenue, expenses, profit, margin)
GET    /api/ledger/growth           (?days=30, default)
GET    /api/ledger/inventory-snapshot
```

## What's still left (unchanged priorities from the original spec)

- Risk engine (deterministic, weighted, explainable) — not built yet
- RAG pipeline (chunking/embeddings/vector store)
- Real GPS/reverse-geocoding backend routes
- Real STT/TTS voice integration
- Frontend pages for the new Business Manager endpoints (Products.jsx, Inventory.jsx,
  Customers.jsx, Invoices.jsx don't exist yet — the API client is ready, the pages aren't)
- Wiring Dashboard/Simulator/MoneyPlanner/etc. to real data
- Admin visibility into the new ledger data

Tell me which to do next — I'd suggest either (a) the frontend pages for what's now built
(Products/Inventory/Customers/Invoices), so you have something clickable, or (b) the risk engine
next since it's the other deterministic-calculation piece the judges will likely poke at.
