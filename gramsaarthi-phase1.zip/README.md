# GramSaarthi — Unified Project (Phase 1)

This is the in-progress merge of three source repos into one product:

- **frontend/** — SIH26S React/Vite UI (kept as the master frontend), now wired to a real backend
- **backend/** — GramSaarthi Express + SQLite API (auth, businesses, financial engine, schemes, chat, admin) — kept as the base backend
- Business Manager (products/inventory/billing) is **not yet ported** — see "What's left" below.

## What's real in this phase

- Real signup/login: bcrypt password hashing, JWT sessions, `/api/auth/*` — no more fake `console.log` login.
- Real session restore: reloading the app calls `/api/auth/me` with the stored JWT.
- Real route protection: `ProtectedRoute` component redirects unauthenticated users to `/login`; the backend independently re-checks the JWT on every request (frontend hiding is never the only guard).
- Real i18n: English/Hindi/Hinglish dictionaries in `frontend/src/i18n/*.json`, loaded through `LanguageContext` — no hardcoded UI strings in the wired pages, no Hinglish leakage into English mode.
- Real API client (`frontend/src/services/`) with JWT attached automatically, 401 handling, and typed error surfacing to the UI (Login/Register now show real backend error messages, not `alert()`).
- The backend's finance engine, EMI calculator, scheme matcher, business recommendation engine, and admin dashboard (already present in the GramSaarthi repo) are preserved as-is — I verified `router.use(requireAuth, requireAdmin)` genuinely gates every admin route.
- AI chat (`/api/chat/*`) already supports a real Anthropic API call when `ANTHROPIC_API_KEY` is set, with a clearly-labeled deterministic fallback when it isn't (not a hallucinated "still live" claim).

## Known limitation of this sandbox

I could not run `npm install` or boot the servers inside this chat's container — outbound network access here is blocked. So:
- I verified every backend `.js` file with `node --check` (all pass — no syntax errors).
- I have **not** been able to execute a live end-to-end request in this environment.
- **You need to run it locally** (steps below) for the real functional test. If something breaks on your machine, tell me the exact error and I'll fix it in the source.

## Run it locally

```powershell
# Backend
cd backend
copy .env.example .env      # then edit AUTH_SECRET at minimum
npm install
npm run seed                # optional demo data
npm run dev                 # http://localhost:4000

# Frontend (new terminal)
cd frontend
copy .env.example .env
npm install
npm run dev                 # http://localhost:5173
```

## What's left (next phases, not in this delivery)

- Business Manager port: products, inventory, customers, invoicing, stock-deduction transactions — none of this exists in the backend yet.
- Growth engine and Risk engine as separate deterministic modules (finance.js currently covers core financial calcs only — I have not yet verified growth/risk formulas against the spec's exact definitions).
- RAG pipeline (chunking/embeddings/vector store) — not present yet.
- Real GPS/reverse-geocoding backend routes — not present yet; catalog.js only serves a static demo location list.
- Real STT/TTS voice integration — VoiceAdvisor.jsx still needs wiring; no voice routes exist in the backend yet.
- Wiring the remaining pages (Dashboard, LocalBusiness, MoneyPlanner, Simulator, SchemeMatcher, Reports, Onboarding) to the now-real API client — they still use placeholder/local data.
- Automated tests (auth, billing math, EMI, growth, risk, scheme matching).

I'll continue phase by phase — tell me which of the "what's left" items to tackle next, or say "continue" and I'll go in the spec's original phase order (Business Manager port next).
