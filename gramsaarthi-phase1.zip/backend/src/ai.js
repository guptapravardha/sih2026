// AI adapter: calls Anthropic if ANTHROPIC_API_KEY is set in .env,
// otherwise uses a deterministic, context-grounded fallback so the
// product never breaks in a live demo without a key.

const F = require("./finance");
const { bizById, locById } = require("./data");

const SYSTEM_PROMPTS = {
  en: `You are GramSaarthi's "Rural Business Co-Pilot" — an AI advisor for rural micro-entrepreneurs in India. Respond ONLY in English. Be concise, practical, and honest about uncertainty. Never invent interest rates, scheme rules, or guaranteed profits. Use the structured user/business context you are given; do not assume facts not provided.`,
  hi: `आप ग्रामसारथी के "ग्रामीण व्यवसाय सह-पायलट" हैं — भारत में ग्रामीण सूक्ष्म-उद्यमियों के लिए एक AI सलाहकार। केवल हिंदी में उत्तर दें। संक्षिप्त, व्यावहारिक रहें और अनिश्चितता के बारे में ईमानदार रहें। कभी भी ब्याज दरें, योजना नियम या गारंटीड लाभ न बनाएं। दिए गए संरचित संदर्भ का उपयोग करें।`,
  hinglish: `Aap GramSaarthi ke "Rural Business Co-Pilot" hain — India ke rural micro-entrepreneurs ke liye AI advisor. SIRF natural Hinglish (Roman Hindi) mein jawab dein, English ya pure Hindi script mein nahi. Concise aur practical rahein, uncertainty ke baare mein honest rahein. Interest rates, scheme rules ya guaranteed profit kabhi mat banayein. Diya gaya context hi use karein.`
};

async function callAnthropic(messages, system) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 600,
        system,
        messages
      })
    });
    if (!res.ok) return null;
    const data = await res.json();
    const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
    return text || null;
  } catch {
    return null;
  }
}

// Localized affordability labels/detail — the underlying finance engine's
// `label`/`hi` fields are always Hinglish, so for `en`/`hi` chat we translate
// by affordability `level` instead of surfacing that raw text.
const AFFORD_LABEL = {
  none: { en: "No loan needed", hi: "ऋण की आवश्यकता नहीं", hinglish: "Loan ki zaroorat nahi" },
  ok: { en: "Comfortable", hi: "आरामदायक", hinglish: "Comfortable" },
  mid: { en: "Manage with caution", hi: "सावधानी से चलाएं", hinglish: "Sambhal kar chalayein" },
  bad: { en: "High risk right now", hi: "अभी बहुत जोखिम भरा", hinglish: "Abhi bahut risky" }
};
const AFFORD_DETAIL = {
  none: { en: "Your own capital fully covers the project.", hi: "आपकी अपनी पूंजी पूरी परियोजना को कवर कर रही है।", hinglish: "Aapka apna paisa poora project cover kar raha hai." },
  ok: { en: "There's a healthy margin left after the EMI.", hi: "ईएमआई के बाद अच्छी बचत रहती है।", hinglish: "EMI ke baad theek paisa bachta hai." },
  mid: { en: "The EMI is payable, but the safety margin is thin.", hi: "ईएमआई निकल जाएगी, लेकिन सुरक्षा मार्जिन कम है।", hinglish: "EMI nikal jayegi, lekin safety margin kam hai." },
  bad: { en: "The business income doesn't comfortably cover the EMI.", hi: "व्यवसाय की आय से ईएमआई आराम से नहीं निकल रही।", hinglish: "Business ki kamai se EMI aaram se nahi nikal rahi." }
};
function affordLabel(level, lang) { return (AFFORD_LABEL[level] || AFFORD_LABEL.mid)[lang]; }
function affordDetail(a, lang) { return (AFFORD_DETAIL[a.level] || AFFORD_DETAIL.mid)[lang]; }

// Deterministic, grounded fallback — no hallucination, uses real stored data.
function fallbackReply(userMessage, context, lang) {
  const { financialProfile, businesses, activePlan } = context;
  const msg = (userMessage || "").toLowerCase();

  const L = {
    en: {
      greet: "I'm your Rural Business Co-Pilot.",
      noCapital: "I don't have your capital amount yet — add it in your Financial Profile so I can give specific numbers.",
      capitalLine: (c) => `You have ${F.inr(c)} available capital.`,
      noBiz: "You haven't created a business yet. Go to My Business to set one up, and I can analyse it for you.",
      planLine: (p) => `For "${p.name}": projected monthly profit is ${F.inr(p.profit)}, and total project cost is ${F.inr(p.total)}.`,
      afford: (a) => `Loan affordability looks "${affordLabel(a.level, "en")}" — ${affordDetail(a, "en")}`,
      unavailable: "I don't have verified live data for that yet — this is a demo-mode estimate based on your stored numbers, not real-time market data.",
      closer: "Ask me about your loan affordability, break-even, or a specific business idea and I'll use your saved numbers."
    },
    hi: {
      greet: "मैं आपका ग्रामीण व्यवसाय सह-पायलट हूँ।",
      noCapital: "मेरे पास अभी आपकी पूंजी की जानकारी नहीं है — कृपया अपनी वित्तीय प्रोफ़ाइल में जोड़ें।",
      capitalLine: (c) => `आपके पास ${F.inr(c)} उपलब्ध पूंजी है।`,
      noBiz: "आपने अभी तक कोई व्यवसाय नहीं बनाया है। 'मेरा व्यवसाय' में जाकर एक बनाएं, फिर मैं उसका विश्लेषण कर सकता हूँ।",
      planLine: (p) => `"${p.name}" के लिए: अनुमानित मासिक लाभ ${F.inr(p.profit)} है, और कुल परियोजना लागत ${F.inr(p.total)} है।`,
      afford: (a) => `ऋण वहनीयता "${affordLabel(a.level, "hi")}" दिखती है — ${affordDetail(a, "hi")}`,
      unavailable: "मेरे पास इसके लिए सत्यापित लाइव डेटा नहीं है — यह आपके सहेजे गए आंकड़ों पर आधारित डेमो अनुमान है, वास्तविक समय का बाज़ार डेटा नहीं।",
      closer: "मुझसे अपनी ऋण वहनीयता, ब्रेक-ईवन, या किसी खास व्यवसाय के बारे में पूछें।"
    },
    hinglish: {
      greet: "Main aapka Rural Business Co-Pilot hoon.",
      noCapital: "Abhi aapki capital ki jaankari mere paas nahi hai — apni Financial Profile mein add karein.",
      capitalLine: (c) => `Aapke paas ${F.inr(c)} available capital hai.`,
      noBiz: "Aapne abhi tak koi business nahi banaya hai. 'My Business' mein jaakar ek banayein, phir main usska analysis kar sakta hoon.",
      planLine: (p) => `"${p.name}" ke liye: estimated monthly profit ${F.inr(p.profit)} hai, aur total project cost ${F.inr(p.total)} hai.`,
      afford: (a) => `Loan affordability "${affordLabel(a.level, "hinglish")}" dikh rahi hai — ${affordDetail(a, "hinglish")}`,
      unavailable: "Iske liye mere paas verified live data nahi hai — yeh aapke saved numbers par based demo estimate hai, real-time market data nahi.",
      closer: "Mujhse apni loan affordability, break-even, ya kisi specific business idea ke baare mein poochein."
    }
  }[lang] || {};

  const parts = [];
  if (!financialProfile || !financialProfile.capital) {
    parts.push(L.noCapital);
  } else {
    parts.push(L.capitalLine(financialProfile.capital));
  }

  if (!businesses || businesses.length === 0) {
    parts.push(L.noBiz);
  } else if (activePlan) {
    const proj = JSON.parse(activePlan.projection);
    const struct = JSON.parse(activePlan.structure);
    const afford = JSON.parse(activePlan.affordability);
    parts.push(L.planLine({ name: businesses[0].name, profit: proj.profit, total: struct.total }));
    parts.push(L.afford(afford));
  }

  parts.push(L.unavailable);
  parts.push(L.closer);
  return parts.filter(Boolean).join(" ");
}

async function getAssistantReply({ userMessage, history, context, lang }) {
  const system = SYSTEM_PROMPTS[lang] || SYSTEM_PROMPTS.hinglish;
  const contextBlock = `User context (only use what's relevant):\n${JSON.stringify(context, null, 2)}`;
  const messages = [
    ...history.map(h => ({ role: h.role === "assistant" ? "assistant" : "user", content: h.content })),
    { role: "user", content: `${contextBlock}\n\nUser message: ${userMessage}` }
  ];
  const real = await callAnthropic(messages, system);
  if (real) return { reply: real, source: "live" };
  return { reply: fallbackReply(userMessage, context, lang), source: "fallback" };
}

module.exports = { getAssistantReply };
