require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(require("path").join(__dirname, "..", "public")));

app.use("/api/auth", require("./routes/auth"));
app.use("/api/profile", require("./routes/profile"));
app.use("/api/catalog", require("./routes/catalog"));
app.use("/api/businesses", require("./routes/businesses"));
app.use("/api/financial", require("./routes/financial"));
app.use("/api/scenarios", require("./routes/scenarios"));
app.use("/api/schemes", require("./routes/schemes"));
app.use("/api/chat", require("./routes/chat"));
app.use("/api/admin", require("./routes/admin"));
app.use("/api/notifications", require("./routes/notifications"));

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    db: "connected",
    ai: process.env.ANTHROPIC_API_KEY ? "live" : "fallback",
    time: new Date().toISOString()
  });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || "Internal server error" });
});

app.use((req, res) => res.status(404).json({ error: "Not found" }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`GramSaarthi API listening on :${PORT}`));
