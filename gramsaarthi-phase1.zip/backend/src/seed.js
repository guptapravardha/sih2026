require("dotenv").config();
const bcrypt = require("bcryptjs");
const db = require("./db");
const F = require("./finance");
const { bizById, locById } = require("./data");

function upsertUser({ name, email, password, role, language }) {
  let user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (user) return user;
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare("INSERT INTO users (name, email, password_hash, role, language) VALUES (?, ?, ?, ?, ?)")
    .run(name, email, hash, role, language);
  db.prepare("INSERT INTO user_profiles (user_id) VALUES (?)").run(info.lastInsertRowid);
  db.prepare("INSERT INTO financial_profiles (user_id) VALUES (?)").run(info.lastInsertRowid);
  return db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
}

function seedBusiness(user, { name, bizId, locId, scale, capital, occupation, experienceYears, resources }) {
  db.prepare(`UPDATE user_profiles SET loc_id=?, occupation=?, experience_years=?, resources=? WHERE user_id=?`)
    .run(locId, occupation, experienceYears, JSON.stringify(resources), user.id);
  db.prepare(`UPDATE financial_profiles SET capital=? WHERE user_id=?`).run(capital, user.id);

  const info = db.prepare("INSERT INTO businesses (user_id, name, biz_catalog_id, loc_id, scale) VALUES (?, ?, ?, ?, ?)")
    .run(user.id, name, bizId, locId, scale);
  const business = db.prepare("SELECT * FROM businesses WHERE id = ?").get(info.lastInsertRowid);

  const biz = bizById(bizId);
  const loc = locById(locId);
  const assumptions = F.buildAssumptions(biz, loc, scale);
  const projection = F.project(assumptions);
  const structure = F.structure(assumptions, capital);
  const affordability = F.affordability(assumptions, capital, 0);
  const returns = F.returns(assumptions, capital);
  db.prepare(`INSERT INTO business_plans (business_id, user_id, assumptions, projection, structure, affordability, returns)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(business.id, user.id, JSON.stringify(assumptions), JSON.stringify(projection),
    JSON.stringify(structure), JSON.stringify(affordability), JSON.stringify(returns));

  return business;
}

const admin = upsertUser({ name: "Admin", email: "admin@gramsaarthi.demo", password: "Admin@123", role: "admin", language: "en" });

const ramesh = upsertUser({ name: "Ramesh Kumar", email: "ramesh@demo.gramsaarthi", password: "Demo@123", role: "user", language: "hinglish" });
seedBusiness(ramesh, { name: "Ramesh Dairy Unit", bizId: "dairy", locId: "loc1", scale: "balanced", capital: 100000, occupation: "Farmer", experienceYears: 2, resources: ["shed", "water", "labour", "land"] });

const sunita = upsertUser({ name: "Sunita Devi", email: "sunita@demo.gramsaarthi", password: "Demo@123", role: "user", language: "hi" });
seedBusiness(sunita, { name: "Sunita Vegetable Trading", bizId: "vegetable", locId: "loc2", scale: "pilot", capital: 40000, occupation: "Homemaker", experienceYears: 0, resources: ["vehicle", "customers"] });

const arjun = upsertUser({ name: "Arjun Patel", email: "arjun@demo.gramsaarthi", password: "Demo@123", role: "user", language: "en" });
seedBusiness(arjun, { name: "Arjun Spice Processing", bizId: "spice", locId: "loc3", scale: "balanced", capital: 150000, occupation: "Trader", experienceYears: 4, resources: ["shop", "storage", "labour"] });

for (const u of [ramesh, sunita, arjun]) {
  db.prepare("INSERT INTO notifications (user_id, type, title, body) VALUES (?, 'market', ?, ?)")
    .run(u.id, "Market price updated", "A commodity price relevant to your business changed this week.");
}

console.log("Seed complete.");
console.log("Admin login: admin@gramsaarthi.demo / Admin@123");
console.log("Demo users: ramesh@demo.gramsaarthi / sunita@demo.gramsaarthi / arjun@demo.gramsaarthi — password Demo@123");
