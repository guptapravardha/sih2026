const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");
const F = require("../finance");
const engine = require("../engine");
const { bizById, locById } = require("../data");

const router = express.Router();

router.get("/", requireAuth, (req, res) => {
  const businesses = db.prepare("SELECT * FROM businesses WHERE user_id = ? ORDER BY created_at DESC").all(req.user.id);
  res.json({ businesses });
});

const createSchema = z.object({
  name: z.string().min(2).max(120),
  bizCatalogId: z.string(),
  locId: z.string().optional(),
  scale: z.enum(["pilot", "balanced", "aggressive"]).default("balanced")
});

router.post("/", requireAuth, (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { name, bizCatalogId, locId, scale } = parsed.data;
  const biz = bizById(bizCatalogId);
  if (!biz) return res.status(400).json({ error: "Unknown business category" });

  const info = db.prepare(
    "INSERT INTO businesses (user_id, name, biz_catalog_id, loc_id, scale) VALUES (?, ?, ?, ?, ?)"
  ).run(req.user.id, name, bizCatalogId, locId || null, scale);

  const business = db.prepare("SELECT * FROM businesses WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ business });
});

router.get("/:id", requireAuth, (req, res) => {
  const business = db.prepare("SELECT * FROM businesses WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!business) return res.status(404).json({ error: "Business not found" });
  const plans = db.prepare("SELECT * FROM business_plans WHERE business_id = ? AND archived = 0 ORDER BY created_at DESC").all(business.id);
  res.json({ business, plans: plans.map(deserializePlan) });
});

router.delete("/:id", requireAuth, (req, res) => {
  const business = db.prepare("SELECT * FROM businesses WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!business) return res.status(404).json({ error: "Business not found" });
  db.prepare("DELETE FROM businesses WHERE id = ?").run(business.id);
  res.json({ ok: true });
});

// Generate (and persist) a fresh financial plan for a business using the deterministic engine.
router.post("/:id/plan", requireAuth, (req, res) => {
  const business = db.prepare("SELECT * FROM businesses WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!business) return res.status(404).json({ error: "Business not found" });

  const fin = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  const capital = (fin && fin.capital) || 0;
  const biz = bizById(business.biz_catalog_id);
  const loc = business.loc_id ? locById(business.loc_id) : null;
  if (!biz) return res.status(400).json({ error: "Unknown business category on record" });

  const assumptions = F.buildAssumptions(biz, loc, business.scale);
  const projection = F.project(assumptions);
  const structure = F.structure(assumptions, capital);
  const affordability = F.affordability(assumptions, capital, (fin && fin.existing_emi) || 0);
  const returns = F.returns(assumptions, capital);

  const info = db.prepare(`INSERT INTO business_plans
    (business_id, user_id, assumptions, projection, structure, affordability, returns)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(
    business.id, req.user.id, JSON.stringify(assumptions), JSON.stringify(projection),
    JSON.stringify(structure), JSON.stringify(affordability), JSON.stringify(returns)
  );

  const plan = db.prepare("SELECT * FROM business_plans WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ plan: deserializePlan(plan) });
});

router.get("/:id/plans", requireAuth, (req, res) => {
  const business = db.prepare("SELECT * FROM businesses WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!business) return res.status(404).json({ error: "Business not found" });
  const plans = db.prepare("SELECT * FROM business_plans WHERE business_id = ? AND archived = 0 ORDER BY created_at DESC").all(business.id);
  res.json({ plans: plans.map(deserializePlan) });
});

router.delete("/:id/plans/:planId", requireAuth, (req, res) => {
  const plan = db.prepare("SELECT * FROM business_plans WHERE id = ? AND user_id = ?").get(req.params.planId, req.user.id);
  if (!plan) return res.status(404).json({ error: "Plan not found" });
  db.prepare("UPDATE business_plans SET archived = 1 WHERE id = ?").run(plan.id);
  res.json({ ok: true });
});

// Structured business recommendation engine — considers capital, resources, location, experience, risk.
router.get("/recommend/for-me", requireAuth, (req, res) => {
  const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(req.user.id);
  const fin = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  if (!profile) return res.status(400).json({ error: "Complete your profile first" });

  const userProfile = {
    locId: profile.loc_id,
    capital: (fin && fin.capital) || 0,
    resources: JSON.parse(profile.resources || "[]"),
    interests: JSON.parse(profile.interests || "[]"),
    occupation: profile.occupation,
    experienceYears: profile.experience_years,
    existingEmi: (fin && fin.existing_emi) || 0
  };
  const recs = engine.recommend(userProfile, 5);
  res.json({
    recommendations: recs.map(r => ({
      bizId: r.biz.id, name: r.biz.name, icon: r.biz.icon, score: r.score,
      parts: r.parts, scale: r.scale, projection: r.projection, structure: r.structure,
      affordability: r.afford, returns: r.ret, stress: r.stress, userAsked: !!r.userAsked
    }))
  });
});

function deserializePlan(p) {
  return {
    ...p,
    assumptions: JSON.parse(p.assumptions),
    projection: JSON.parse(p.projection),
    structure: JSON.parse(p.structure),
    affordability: JSON.parse(p.affordability),
    returns: JSON.parse(p.returns)
  };
}

module.exports = router;
