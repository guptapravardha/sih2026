const express = require("express");
const db = require("../db");
const { requireAuth } = require("../auth");
const { SCHEMES } = require("../data");
const { matchSchemes } = require("../schemes");
const router = express.Router();

router.get("/", (req, res) => res.json({ schemes: SCHEMES, note: "Demo scheme dataset for prototype purposes — verify with official sources before relying on it." }));

router.get("/for-business/:businessId", requireAuth, (req, res) => {
  const business = db.prepare("SELECT * FROM businesses WHERE id = ? AND user_id = ?").get(req.params.businessId, req.user.id);
  if (!business) return res.status(404).json({ error: "Business not found" });
  const fin = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  const matches = matchSchemes(business.biz_catalog_id, (fin && fin.capital) || 0);

  const insert = db.prepare(`INSERT INTO scheme_matches (user_id, business_id, scheme_id, match_level, reason) VALUES (?, ?, ?, ?, ?)`);
  const tx = db.transaction((rows) => { for (const m of rows) insert.run(req.user.id, business.id, m.schemeId, m.level, m.reason); });
  tx(matches);

  res.json({ matches, disclaimer: "Final eligibility should be verified with the official authority." });
});

module.exports = router;
