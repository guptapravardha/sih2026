const express = require("express");
const { z } = require("zod");
const { requireAuth } = require("../auth");
const F = require("../finance");
const router = express.Router();

const emiSchema = z.object({
  principal: z.number().min(0),
  rate: z.number().min(0).max(60),
  months: z.number().min(1).max(360)
});

router.post("/emi", requireAuth, (req, res) => {
  const parsed = emiSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { principal, rate, months } = parsed.data;
  res.json(F.loanTotals(principal, rate, months));
});

module.exports = router;
