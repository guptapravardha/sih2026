const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");
const F = require("../finance");
const router = express.Router();

router.get("/plan/:planId", requireAuth, (req, res) => {
  const plan = db.prepare("SELECT * FROM business_plans WHERE id = ? AND user_id = ?").get(req.params.planId, req.user.id);
  if (!plan) return res.status(404).json({ error: "Plan not found" });
  const scenarios = db.prepare("SELECT * FROM financial_scenarios WHERE business_plan_id = ? ORDER BY created_at DESC").all(plan.id);
  res.json({ scenarios: scenarios.map(s => ({ ...s, deltas: JSON.parse(s.deltas), result: JSON.parse(s.result) })) });
});

const deltaSchema = z.object({
  label: z.string().min(1).max(120),
  pricePct: z.number().optional(),
  varCostPct: z.number().optional(),
  unitsPct: z.number().optional(),
  fixedPct: z.number().optional()
});

router.post("/plan/:planId", requireAuth, (req, res) => {
  const parsed = deltaSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const plan = db.prepare("SELECT * FROM business_plans WHERE id = ? AND user_id = ?").get(req.params.planId, req.user.id);
  if (!plan) return res.status(404).json({ error: "Plan not found" });

  const { label, ...deltas } = parsed.data;
  const a = JSON.parse(plan.assumptions);
  const na = F.applyDeltas(a, deltas);
  const projection = F.project(na);
  const fin = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  const capital = (fin && fin.capital) || 0;
  const afford = F.affordability(na, capital, (fin && fin.existing_emi) || 0);
  const result = { projection, affordability: afford };

  const info = db.prepare(`INSERT INTO financial_scenarios (business_plan_id, user_id, label, deltas, result)
    VALUES (?, ?, ?, ?, ?)`).run(plan.id, req.user.id, label, JSON.stringify(deltas), JSON.stringify(result));

  const row = db.prepare("SELECT * FROM financial_scenarios WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ scenario: { ...row, deltas: JSON.parse(row.deltas), result: JSON.parse(row.result) } });
});

router.get("/plan/:planId/stress-test", requireAuth, (req, res) => {
  const plan = db.prepare("SELECT * FROM business_plans WHERE id = ? AND user_id = ?").get(req.params.planId, req.user.id);
  if (!plan) return res.status(404).json({ error: "Plan not found" });
  const a = JSON.parse(plan.assumptions);
  const fin = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  const capital = (fin && fin.capital) || 0;
  const result = F.stressTest(a, capital, (fin && fin.existing_emi) || 0);
  res.json({ result });
});

router.delete("/:id", requireAuth, (req, res) => {
  const s = db.prepare("SELECT * FROM financial_scenarios WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!s) return res.status(404).json({ error: "Scenario not found" });
  db.prepare("DELETE FROM financial_scenarios WHERE id = ?").run(s.id);
  res.json({ ok: true });
});

module.exports = router;
