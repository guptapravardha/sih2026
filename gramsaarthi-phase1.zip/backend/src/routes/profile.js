const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");
const router = express.Router();

router.get("/", requireAuth, (req, res) => {
  const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(req.user.id);
  const financial = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  res.json({
    profile: profile ? { ...profile, resources: JSON.parse(profile.resources), interests: JSON.parse(profile.interests) } : null,
    financial
  });
});

const profileSchema = z.object({
  locId: z.string().optional(),
  occupation: z.string().max(100).optional(),
  experienceYears: z.number().min(0).max(60).optional(),
  resources: z.array(z.string()).optional(),
  interests: z.array(z.string()).optional()
});

router.put("/", requireAuth, (req, res) => {
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const d = parsed.data;
  db.prepare(`UPDATE user_profiles SET
    loc_id = COALESCE(?, loc_id), occupation = COALESCE(?, occupation),
    experience_years = COALESCE(?, experience_years),
    resources = COALESCE(?, resources), interests = COALESCE(?, interests),
    updated_at = datetime('now') WHERE user_id = ?`)
    .run(d.locId ?? null, d.occupation ?? null, d.experienceYears ?? null,
         d.resources ? JSON.stringify(d.resources) : null,
         d.interests ? JSON.stringify(d.interests) : null, req.user.id);
  res.json({ ok: true });
});

const financialSchema = z.object({
  capital: z.number().min(0).optional(),
  monthlyIncome: z.number().min(0).optional(),
  monthlyExpenses: z.number().min(0).optional(),
  existingDebt: z.number().min(0).optional(),
  existingEmi: z.number().min(0).optional(),
  emergencySavings: z.number().min(0).optional(),
  riskTolerance: z.enum(["low", "medium", "high"]).optional(),
  targetIncome: z.number().min(0).optional()
});

router.put("/financial", requireAuth, (req, res) => {
  const parsed = financialSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const d = parsed.data;
  db.prepare(`UPDATE financial_profiles SET
    capital = COALESCE(?, capital), monthly_income = COALESCE(?, monthly_income),
    monthly_expenses = COALESCE(?, monthly_expenses), existing_debt = COALESCE(?, existing_debt),
    existing_emi = COALESCE(?, existing_emi), emergency_savings = COALESCE(?, emergency_savings),
    risk_tolerance = COALESCE(?, risk_tolerance), target_income = COALESCE(?, target_income),
    updated_at = datetime('now') WHERE user_id = ?`)
    .run(d.capital ?? null, d.monthlyIncome ?? null, d.monthlyExpenses ?? null, d.existingDebt ?? null,
         d.existingEmi ?? null, d.emergencySavings ?? null, d.riskTolerance ?? null, d.targetIncome ?? null,
         req.user.id);
  res.json({ ok: true });
});

module.exports = router;
