const express = require("express");
const db = require("../db");
const { requireAuth } = require("../auth");
const router = express.Router();

router.get("/", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50").all(req.user.id);
  res.json({ notifications: rows });
});

router.post("/:id/read", requireAuth, (req, res) => {
  const n = db.prepare("SELECT * FROM notifications WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!n) return res.status(404).json({ error: "Notification not found" });
  db.prepare("UPDATE notifications SET is_read = 1 WHERE id = ?").run(n.id);
  res.json({ ok: true });
});

module.exports = router;
