const express = require("express");
const { BUSINESSES, LOCATIONS, RESOURCES, STATES } = require("../data");
const router = express.Router();

router.get("/businesses", (req, res) => res.json({ businesses: BUSINESSES }));
router.get("/locations", (req, res) => res.json({ locations: LOCATIONS, note: "Demo location dataset — labelled clearly, replace with a real geo/market data source for production." }));
router.get("/resources", (req, res) => res.json({ resources: RESOURCES }));
router.get("/states", (req, res) => res.json({ states: STATES }));

module.exports = router;
