const express = require("express");
const db = require("../db");
const { requireAuth, requireAdmin } = require("../auth");
const router = express.Router();

router.use(requireAuth, requireAdmin);

router.get("/overview", (req, res) => {
  const totalUsers = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'user'").get().c;
  const activeUsers = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'user' AND is_active = 1").get().c;
  const totalBusinesses = db.prepare("SELECT COUNT(*) c FROM businesses").get().c;
  const totalPlans = db.prepare("SELECT COUNT(*) c FROM business_plans WHERE archived = 0").get().c;
  const totalConversations = db.prepare("SELECT COUNT(*) c FROM conversations").get().c;
  const totalMessages = db.prepare("SELECT COUNT(*) c FROM messages").get().c;
  const langBreakdown = db.prepare("SELECT language, COUNT(*) c FROM users GROUP BY language").all();
  res.json({
    users: { total: totalUsers, active: activeUsers, byLanguage: langBreakdown },
    businesses: { total: totalBusinesses },
    plans: { total: totalPlans },
    aiUsage: { conversations: totalConversations, messages: totalMessages, mode: process.env.ANTHROPIC_API_KEY ? "live" : "fallback" },
    systemHealth: { db: "ok", api: "ok", ai: process.env.ANTHROPIC_API_KEY ? "live" : "fallback (no API key set)" }
  });
});

router.get("/users", (req, res) => {
  const users = db.prepare(`SELECT id, name, email, role, language, is_active, created_at FROM users ORDER BY created_at DESC`).all();
  res.json({ users });
});

router.get("/users/:id", (req, res) => {
  const user = db.prepare("SELECT id, name, email, role, language, is_active, created_at FROM users WHERE id = ?").get(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(user.id);
  const financial = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(user.id);
  const businesses = db.prepare("SELECT * FROM businesses WHERE user_id = ?").all(user.id);
  res.json({
    user,
    profile: profile ? { ...profile, resources: JSON.parse(profile.resources), interests: JSON.parse(profile.interests) } : null,
    financial,
    businesses
  });
});

router.post("/users/:id/disable", (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  db.prepare("UPDATE users SET is_active = 0 WHERE id = ?").run(user.id);
  db.prepare("INSERT INTO audit_logs (admin_id, action, entity, entity_id) VALUES (?, 'disable_user', 'user', ?)")
    .run(req.user.id, String(user.id));
  res.json({ ok: true });
});

router.post("/users/:id/enable", (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  db.prepare("UPDATE users SET is_active = 1 WHERE id = ?").run(user.id);
  db.prepare("INSERT INTO audit_logs (admin_id, action, entity, entity_id) VALUES (?, 'enable_user', 'user', ?)")
    .run(req.user.id, String(user.id));
  res.json({ ok: true });
});

router.get("/businesses", (req, res) => {
  const businesses = db.prepare(`
    SELECT b.*, u.name as owner_name, u.email as owner_email
    FROM businesses b JOIN users u ON u.id = b.user_id ORDER BY b.created_at DESC`).all();
  res.json({ businesses });
});

router.get("/audit-logs", (req, res) => {
  const logs = db.prepare("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200").all();
  res.json({ logs });
});

module.exports = router;
