const express = require("express");
const { z } = require("zod");
const db = require("../db");
const { requireAuth } = require("../auth");
const { getAssistantReply } = require("../ai");
const router = express.Router();

router.get("/conversations", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM conversations WHERE user_id = ? ORDER BY updated_at DESC").all(req.user.id);
  res.json({ conversations: rows });
});

router.post("/conversations", requireAuth, (req, res) => {
  const user = db.prepare("SELECT language FROM users WHERE id = ?").get(req.user.id);
  const info = db.prepare("INSERT INTO conversations (user_id, title, language) VALUES (?, ?, ?)")
    .run(req.user.id, "New chat", user.language);
  const conv = db.prepare("SELECT * FROM conversations WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ conversation: conv });
});

router.put("/conversations/:id", requireAuth, (req, res) => {
  const conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!conv) return res.status(404).json({ error: "Conversation not found" });
  const title = (req.body.title || "").slice(0, 120) || conv.title;
  db.prepare("UPDATE conversations SET title = ?, updated_at = datetime('now') WHERE id = ?").run(title, conv.id);
  res.json({ ok: true });
});

router.delete("/conversations/:id", requireAuth, (req, res) => {
  const conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!conv) return res.status(404).json({ error: "Conversation not found" });
  db.prepare("DELETE FROM conversations WHERE id = ?").run(conv.id);
  res.json({ ok: true });
});

router.get("/conversations/:id/messages", requireAuth, (req, res) => {
  const conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!conv) return res.status(404).json({ error: "Conversation not found" });
  const messages = db.prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC").all(conv.id);
  res.json({ messages });
});

const sendSchema = z.object({ message: z.string().min(1).max(2000) });

router.post("/conversations/:id/messages", requireAuth, async (req, res) => {
  const parsed = sendSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!conv) return res.status(404).json({ error: "Conversation not found" });

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  const profile = db.prepare("SELECT * FROM user_profiles WHERE user_id = ?").get(req.user.id);
  const financialProfile = db.prepare("SELECT * FROM financial_profiles WHERE user_id = ?").get(req.user.id);
  const businesses = db.prepare("SELECT * FROM businesses WHERE user_id = ?").all(req.user.id);
  const activePlan = businesses.length
    ? db.prepare("SELECT * FROM business_plans WHERE business_id = ? AND archived = 0 ORDER BY created_at DESC").get(businesses[0].id)
    : null;

  const history = db.prepare("SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT 20").all(conv.id);

  db.prepare("INSERT INTO messages (conversation_id, role, content) VALUES (?, 'user', ?)").run(conv.id, parsed.data.message);

  // Controlled context — only what's relevant, never the whole DB.
  const context = {
    name: user.name,
    language: user.language,
    location: profile && profile.loc_id,
    occupation: profile && profile.occupation,
    financialProfile: financialProfile ? {
      capital: financialProfile.capital, monthlyIncome: financialProfile.monthly_income,
      monthlyExpenses: financialProfile.monthly_expenses, existingEmi: financialProfile.existing_emi,
      riskTolerance: financialProfile.risk_tolerance
    } : null,
    businesses: businesses.map(b => ({ name: b.name, category: b.biz_catalog_id, scale: b.scale })),
    activePlan
  };

  let result;
  try {
    result = await getAssistantReply({ userMessage: parsed.data.message, history, context, lang: user.language });
  } catch (e) {
    result = { reply: "The AI service is temporarily unavailable. The financial engine keeps working independently — try the Financial Plan or Loan Affordability tools.", source: "error" };
  }

  db.prepare("INSERT INTO messages (conversation_id, role, content, metadata) VALUES (?, 'assistant', ?, ?)")
    .run(conv.id, result.reply, JSON.stringify({ source: result.source }));
  db.prepare("UPDATE conversations SET updated_at = datetime('now'), title = CASE WHEN title = 'New chat' THEN ? ELSE title END WHERE id = ?")
    .run(parsed.data.message.slice(0, 60), conv.id);

  res.json({ reply: result.reply, source: result.source });
});

module.exports = router;
