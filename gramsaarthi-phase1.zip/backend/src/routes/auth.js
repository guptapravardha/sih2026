const express = require("express");
const bcrypt = require("bcryptjs");
const { z } = require("zod");
const db = require("../db");
const { signToken, requireAuth } = require("../auth");

const router = express.Router();

const signupSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(6).max(100),
  language: z.enum(["en", "hi", "hinglish"]).optional()
});

router.post("/signup", (req, res) => {
  const parsed = signupSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { name, email, password, language } = parsed.data;

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) return res.status(409).json({ error: "An account with this email already exists" });

  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare(
    "INSERT INTO users (name, email, password_hash, language) VALUES (?, ?, ?, ?)"
  ).run(name, email, hash, language || "hinglish");

  db.prepare("INSERT INTO user_profiles (user_id) VALUES (?)").run(info.lastInsertRowid);
  db.prepare("INSERT INTO financial_profiles (user_id) VALUES (?)").run(info.lastInsertRowid);

  const user = db.prepare("SELECT id, name, email, role, language FROM users WHERE id = ?").get(info.lastInsertRowid);
  const token = signToken(user);
  res.status(201).json({ token, user });
});

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

router.post("/login", (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid email or password" });
  const { email, password } = parsed.data;

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !user.is_active) return res.status(401).json({ error: "Invalid email or password" });

  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: "Invalid email or password" });

  const token = signToken(user);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, language: user.language } });
});

router.get("/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id, name, email, role, language FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user });
});

router.post("/language", requireAuth, (req, res) => {
  const lang = req.body.language;
  if (!["en", "hi", "hinglish"].includes(lang)) return res.status(400).json({ error: "Invalid language" });
  db.prepare("UPDATE users SET language = ?, updated_at = datetime('now') WHERE id = ?").run(lang, req.user.id);
  res.json({ ok: true, language: lang });
});

module.exports = router;
