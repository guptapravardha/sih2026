const { SCHEMES, bizById } = require("./data");

// Rule-based matching — never delegated to an LLM.
function matchSchemes(businessCatalogId, capital) {
  const biz = bizById(businessCatalogId);
  if (!biz) return [];
  return SCHEMES.map(s => {
    let level = "not_a_strong_match";
    let reason = `${s.name} does not directly target ${biz.name} in the current ruleset.`;
    const tagMatch = (s.tags || []).includes(biz.tag);
    const capitalOk = capital >= (s.minCapital || 0) && capital <= (s.maxProject || Infinity);
    if (tagMatch && capitalOk) {
      level = "highly_relevant";
      reason = `${s.name} explicitly lists ${biz.tag}-type businesses and your capital fits its project range.`;
    } else if (tagMatch) {
      level = "potentially_relevant";
      reason = `${s.name} covers ${biz.tag}-type businesses, but your capital is outside its typical project range (${s.minCapital || 0}–${s.maxProject}).`;
    } else if (capitalOk) {
      level = "potentially_relevant";
      reason = `${s.name} fits your capital range but is not specifically tagged for ${biz.tag}.`;
    }
    return {
      schemeId: s.id, name: s.name, purpose: s.purpose, forWhom: s.forWhom,
      supportType: s.supportType, docs: s.docs, route: s.route,
      level, reason
    };
  }).sort((a, b) => {
    const rank = { highly_relevant: 0, potentially_relevant: 1, not_a_strong_match: 2 };
    return rank[a.level] - rank[b.level];
  });
}

module.exports = { matchSchemes };
