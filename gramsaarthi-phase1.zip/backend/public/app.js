/* GramSaarthi frontend — vanilla JS SPA, hash routing, real i18n, real API calls. */
const API = "/api";
const state = {
  token: localStorage.getItem("gs_token") || null,
  user: JSON.parse(localStorage.getItem("gs_user") || "null"),
  lang: localStorage.getItem("gs_lang") || "hinglish",
  dict: {},
  catalog: { businesses: [], locations: [], resources: [] }
};

/* ---------------- i18n ---------------- */
async function loadDict(lang) {
  const res = await fetch(`/i18n/${lang}.json`);
  state.dict = await res.json();
}
function t(key, vars) {
  let s = state.dict[key] || key;
  if (vars) for (const k in vars) s = s.replace(`{${k}}`, vars[k]);
  return s;
}
async function setLang(lang) {
  state.lang = lang;
  localStorage.setItem("gs_lang", lang);
  await loadDict(lang);
  if (state.token) {
    api("/auth/language", { method: "POST", body: { language: lang } }).catch(() => {});
  }
  render();
}

/* ---------------- API helper ---------------- */
async function api(path, { method = "GET", body } = {}) {
  const headers = { "content-type": "application/json" };
  if (state.token) headers.authorization = `Bearer ${state.token}`;
  const res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data;
  try { data = await res.json(); } catch { data = {}; }
  if (!res.ok) {
    const err = new Error(data.error || t("errors.generic"));
    err.status = res.status;
    throw err;
  }
  return data;
}

/* ---------------- toast ---------------- */
function toast(msg, isErr) {
  const el = document.createElement("div");
  el.className = "toast-item" + (isErr ? " err" : "");
  el.textContent = msg;
  document.getElementById("toast").appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

/* ---------------- auth ---------------- */
function logout() {
  state.token = null; state.user = null;
  localStorage.removeItem("gs_token"); localStorage.removeItem("gs_user");
  location.hash = "#/";
}
function saveSession(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem("gs_token", token);
  localStorage.setItem("gs_user", JSON.stringify(user));
}

/* ---------------- router ---------------- */
window.addEventListener("hashchange", render);
window.addEventListener("DOMContentLoaded", boot);

async function boot() {
  await loadDict(state.lang);
  try {
    const res = await fetch("/api/catalog/businesses"); state.catalog.businesses = (await res.json()).businesses;
    const res2 = await fetch("/api/catalog/locations"); state.catalog.locations = (await res2.json()).locations;
    const res3 = await fetch("/api/catalog/resources"); state.catalog.resources = (await res3.json()).resources;
  } catch {}
  if (!location.hash) location.hash = "#/";
  render();
}

function icon(name) {
  const m = {
    money: "💰", market: "📈", business: "🏪", risk: "⚠️", schemes: "📜",
    voice: "🎙️", location: "📍", analytics: "📊", profile: "👤", chat: "💬", bell: "🔔"
  };
  return m[name] || "•";
}

/* ---------------- layout ---------------- */
function shell(contentHtml, opts = {}) {
  const authed = !!state.token;
  const active = (r) => (location.hash === r ? "active" : "");
  return `
  <header class="navbar">
    <div class="container" style="display:flex;align-items:center;justify-content:space-between;height:62px;gap:12px">
      <a href="#/" style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:18px;color:var(--forest)" class="serif">
        🌾 ${t("app.name")}
      </a>
      <nav style="display:flex;gap:2px;align-items:center;flex-wrap:wrap">
        ${authed ? `
          <a class="navlink ${active('#/dashboard')}" href="#/dashboard">${t('nav.dashboard')}</a>
          <a class="navlink ${active('#/business')}" href="#/business">${t('nav.myBusiness')}</a>
          <a class="navlink ${active('#/schemes')}" href="#/schemes">${t('nav.schemes')}</a>
          <a class="navlink ${active('#/chat')}" href="#/chat">${t('nav.aiAdvisor')}</a>
          ${state.user && state.user.role === 'admin' ? `<a class="navlink ${active('#/admin')}" href="#/admin">Admin</a>` : ""}
          <a class="navlink ${active('#/profile')}" href="#/profile">${t('nav.profile')}</a>
        ` : ""}
        <select id="langSwitch" class="btn-sm" style="border:1.5px solid var(--border);border-radius:8px;padding:7px 8px;background:#fff;font-weight:600">
          <option value="en" ${state.lang === 'en' ? 'selected' : ''}>English</option>
          <option value="hi" ${state.lang === 'hi' ? 'selected' : ''}>हिन्दी</option>
          <option value="hinglish" ${state.lang === 'hinglish' ? 'selected' : ''}>Hinglish</option>
        </select>
        ${authed
          ? `<button class="btn btn-ghost btn-sm" id="logoutBtn">${t('nav.logout')}</button>`
          : `<a class="btn btn-ghost btn-sm" href="#/login">${t('nav.login')}</a><a class="btn btn-primary btn-sm" href="#/signup">${t('nav.signup')}</a>`}
      </nav>
    </div>
  </header>
  <main id="main">${contentHtml}</main>
  <footer style="padding:40px 0;color:var(--text-mute);font-size:13px;text-align:center">
    GramSaarthi — ${t('app.tagline')}
  </footer>`;
}

function wireLayout() {
  const sel = document.getElementById("langSwitch");
  if (sel) sel.addEventListener("change", (e) => setLang(e.target.value));
  const lo = document.getElementById("logoutBtn");
  if (lo) lo.addEventListener("click", logout);
}

/* ---------------- views ---------------- */
function landingView() {
  return `
  <section style="background:linear-gradient(180deg,#2f3b2f,#20291f);color:#faf6ee;padding:80px 0 90px">
    <div class="container" style="max-width:760px;text-align:center">
      <div style="display:inline-block;background:rgba(217,154,61,.18);color:#d99a3d;padding:6px 14px;border-radius:99px;font-size:12.5px;font-weight:700;margin-bottom:20px">
        AI-Driven Hyper-Local Business Advisory
      </div>
      <h1 class="serif" style="font-size:clamp(28px,5vw,46px);line-height:1.15;margin:0 0 18px">${t('landing.hero.headline')}</h1>
      <p style="font-size:17px;color:#d9d5c4;margin:0 0 30px">${t('landing.hero.subheading')}</p>
      <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
        <a href="#/signup" class="btn btn-primary" style="padding:13px 26px">${t('landing.hero.cta.start')}</a>
        <a href="#/demo" class="btn" style="padding:13px 26px;background:rgba(255,255,255,.1);color:#fff;border:1.5px solid rgba(255,255,255,.25)">${t('landing.hero.cta.demo')}</a>
      </div>
    </div>
  </section>
  <section class="container" style="padding:56px 0">
    <div class="grid3">
      ${[
        [icon('business'), t('buttons.explore'), 'Score every business idea against your capital, resources and local market.'],
        [icon('money'), t('buttons.financialPlan'), 'A deterministic financial engine — EMI, break-even, ROI. No AI guesswork on your numbers.'],
        [icon('market'), t('buttons.marketIntelligence'), 'Hyper-local demand, competition and transport-cost factors, village by village.'],
        [icon('risk'), t('buttons.riskCheck'), 'Stress-test your plan against price drops, cost spikes and weak demand before you invest.'],
        [icon('schemes'), t('buttons.schemes'), 'Structured, rule-based matching to relevant government schemes — never invented by AI.'],
        [icon('chat'), t('buttons.askAI'), 'A business co-pilot that answers in your language, grounded in your real saved numbers.']
      ].map(([ic, title, desc]) => `
        <div class="card">
          <div style="font-size:26px;margin-bottom:10px">${ic}</div>
          <h3 style="margin:0 0 6px;font-size:16px">${title}</h3>
          <p style="margin:0;color:var(--text-mute);font-size:13.5px">${desc}</p>
        </div>`).join("")}
    </div>
  </section>
  <section class="container" style="padding:10px 0 70px">
    <div class="card" style="background:var(--forest);color:#faf6ee;text-align:center;padding:36px">
      <h2 class="serif" style="margin:0 0 8px">${t('buttons.tryDemo')}</h2>
      <p style="color:#d9d5c4;margin:0 0 18px;font-size:14px">See a pre-filled dairy, vegetable-trading, or spice-processing entrepreneur profile instantly.</p>
      <a href="#/demo" class="btn btn-primary">${t('landing.hero.cta.demo')}</a>
    </div>
  </section>`;
}

function demoView() {
  const demos = [
    { email: "ramesh@demo.gramsaarthi", label: "Dairy Entrepreneur — Ramesh Kumar", lang: "hinglish" },
    { email: "sunita@demo.gramsaarthi", label: "Vegetable Trader — Sunita Devi", lang: "hi" },
    { email: "arjun@demo.gramsaarthi", label: "Spice Business — Arjun Patel", lang: "en" }
  ];
  return `
  <div class="container" style="padding:50px 0;max-width:640px">
    <h2 class="serif">SIH Demo Mode</h2>
    <p style="color:var(--text-mute)">Pick a pre-filled entrepreneur to explore instantly. Password for all demo accounts: <code>Demo@123</code></p>
    <div style="display:flex;flex-direction:column;gap:10px;margin-top:16px">
      ${demos.map(d => `
        <button class="card demo-login-btn" data-email="${d.email}" style="text-align:left;display:flex;justify-content:space-between;align-items:center;width:100%;border:1.5px solid var(--border);background:#fff">
          <span style="font-weight:600">${d.label}</span>
          <span class="btn btn-primary btn-sm">Enter →</span>
        </button>`).join("")}
    </div>
  </div>`;
}

function authView(mode) {
  const isLogin = mode === "login";
  return `
  <div class="container" style="max-width:420px;padding:60px 0">
    <div class="card">
      <h2 class="serif" style="margin-top:0">${isLogin ? t('auth.login.title') : t('auth.signup.title')}</h2>
      <form id="authForm" style="display:flex;flex-direction:column;gap:14px">
        ${!isLogin ? `<div><label>${t('auth.name')}</label><input class="input" name="name" required></div>` : ""}
        <div><label>${t('auth.email')}</label><input class="input" type="email" name="email" required></div>
        <div><label>${t('auth.password')}</label><input class="input" type="password" name="password" required minlength="6"></div>
        <button class="btn btn-primary" type="submit" style="margin-top:6px">${isLogin ? t('auth.login.submit') : t('auth.signup.submit')}</button>
      </form>
      <p style="text-align:center;margin-top:16px;font-size:13.5px">
        <a href="${isLogin ? '#/signup' : '#/login'}" style="color:var(--terracotta);font-weight:600">
          ${isLogin ? t('auth.switchToSignup') : t('auth.switchToLogin')}
        </a>
      </p>
    </div>
  </div>`;
}

function statCard(label, value) {
  return `<div class="card"><div style="font-size:12.5px;color:var(--text-mute);font-weight:600">${label}</div><div style="font-size:22px;font-weight:700;margin-top:4px" class="serif">${value}</div></div>`;
}

async function dashboardView() {
  let businesses = [], plan = null;
  try {
    businesses = (await api("/businesses")).businesses;
    if (businesses.length) {
      const detail = await api(`/businesses/${businesses[0].id}`);
      plan = detail.plans[0] || null;
    }
  } catch (e) { toast(e.message, true); }

  const riskBadge = plan ? riskBadgeFor(plan.affordability.level) : "";
  return `
  <div class="container" style="padding:36px 0">
    <h1 class="serif" style="margin:0 0 4px">${t('dashboard.greeting', { name: state.user.name.split(" ")[0] })}</h1>
    <p style="color:var(--text-mute);margin:0 0 24px">${t('dashboard.snapshot')}</p>
    ${businesses.length ? `
      <div class="grid3" style="margin-bottom:24px">
        ${statCard(t('dashboard.business'), businesses[0].name)}
        ${statCard(t('dashboard.monthlyRevenue'), plan ? fmtInr(plan.projection.revenue) : "—")}
        ${statCard(t('dashboard.risk'), riskBadge || "—")}
      </div>
      <div class="grid2">
        <a href="#/business/${businesses[0].id}" class="card" style="display:block">
          <strong>${t('dashboard.continue')}</strong>
          <p style="color:var(--text-mute);font-size:13.5px;margin:6px 0 0">${t('business.overview')} → ${t('business.money')} → ${t('business.risks')}</p>
        </a>
        <a href="#/chat" class="card" style="display:block">
          <strong>${t('buttons.askAI')}</strong>
          <p style="color:var(--text-mute);font-size:13.5px;margin:6px 0 0">${t('chat.placeholder')}</p>
        </a>
      </div>
    ` : `
      <div class="card" style="text-align:center;padding:40px">
        <p style="margin:0 0 14px;color:var(--text-mute)">${t('dashboard.noBusiness')}</p>
        <a href="#/business/new" class="btn btn-primary">${t('dashboard.exploreBusinesses')}</a>
      </div>
    `}
  </div>`;
}

function affordDetailFor(level) {
  const map = {
    none: { en: "Your own capital fully covers the project.", hi: "आपकी अपनी पूंजी पूरी परियोजना को कवर कर रही है।", hinglish: "Aapka apna paisa poora project cover kar raha hai." },
    ok: { en: "There's a healthy margin left after the EMI.", hi: "ईएमआई के बाद अच्छी बचत रहती है।", hinglish: "EMI ke baad theek paisa bachta hai." },
    mid: { en: "The EMI is payable, but the safety margin is thin.", hi: "ईएमआई निकल जाएगी, लेकिन सुरक्षा मार्जिन कम है।", hinglish: "EMI nikal jayegi, lekin safety margin kam hai." },
    bad: { en: "The business income doesn't comfortably cover the EMI.", hi: "व्यवसाय की आय से ईएमआई आराम से नहीं निकल रही।", hinglish: "Business ki kamai se EMI aaram se nahi nikal rahi." }
  };
  return (map[level] || map.mid)[state.lang] || (map[level] || map.mid).hinglish;
}

function riskBadgeFor(level) {
  const map = { ok: ["badge-ok", t("risk.comfortable")], none: ["badge-ok", t("risk.comfortable")], mid: ["badge-mid", t("risk.caution")], bad: ["badge-bad", t("risk.high")] };
  const [cls, label] = map[level] || ["badge-mid", "—"];
  return `<span class="badge ${cls}">${label}</span>`;
}

function fmtInr(n) {
  if (n === null || n === undefined || isNaN(n)) return "—";
  const neg = n < 0; n = Math.abs(Math.round(n));
  let s = n.toString(), last3 = s.slice(-3), rest = s.slice(0, -3);
  if (rest) last3 = "," + last3;
  rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",");
  return (neg ? "-₹" : "₹") + rest + last3;
}

async function businessListView() {
  let businesses = [];
  try { businesses = (await api("/businesses")).businesses; } catch (e) { toast(e.message, true); }
  return `
  <div class="container" style="padding:36px 0">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <h1 class="serif" style="margin:0">${t('nav.myBusiness')}</h1>
      <a href="#/business/new" class="btn btn-primary btn-sm">+ ${t('business.form.create')}</a>
    </div>
    ${businesses.length ? `<div class="grid2">
      ${businesses.map(b => `
        <a href="#/business/${b.id}" class="card" style="display:block">
          <strong>${b.name}</strong>
          <p style="color:var(--text-mute);font-size:13px;margin:6px 0 0">${b.biz_catalog_id} · ${b.scale} · ${b.status}</p>
        </a>`).join("")}
    </div>` : `<div class="card" style="text-align:center;padding:40px;color:var(--text-mute)">${t('dashboard.noBusiness')}</div>`}
  </div>`;
}

function businessNewView() {
  const cats = state.catalog.businesses;
  const locs = state.catalog.locations;
  return `
  <div class="container" style="padding:36px 0;max-width:640px">
    <h1 class="serif">${t('business.form.create')}</h1>
    <form id="bizForm" class="card" style="display:flex;flex-direction:column;gap:14px">
      <div><label>${t('business.form.name')}</label><input class="input" name="name" required placeholder="e.g. My Dairy Unit"></div>
      <div><label>${t('business.form.category')}</label>
        <select class="input" name="bizCatalogId" required>
          ${cats.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join("")}
        </select>
      </div>
      <div><label>${t('onboarding.location')}</label>
        <select class="input" name="locId">
          <option value="">—</option>
          ${locs.map(l => `<option value="${l.id}">${l.village}, ${l.district}</option>`).join("")}
        </select>
      </div>
      <div><label>${t('business.form.scale')}</label>
        <select class="input" name="scale">
          <option value="pilot">Pilot</option>
          <option value="balanced" selected>Balanced</option>
          <option value="aggressive">Aggressive</option>
        </select>
      </div>
      <div><label>${t('onboarding.capital')}</label><input class="input" type="number" name="capital" min="0" placeholder="100000"></div>
      <button class="btn btn-primary" type="submit">${t('business.form.create')}</button>
    </form>
  </div>`;
}

async function businessDetailView(id) {
  let business, plans, matches = null, stress = null;
  try {
    const d = await api(`/businesses/${id}`);
    business = d.business; plans = d.plans;
  } catch (e) { toast(e.message, true); return `<div class="container" style="padding:40px 0">${t('errors.generic')}</div>`; }

  const plan = plans[0];
  return `
  <div class="container" style="padding:36px 0">
    <h1 class="serif" style="margin-bottom:2px">${business.name}</h1>
    <p style="color:var(--text-mute);margin-top:0">${business.biz_catalog_id} · ${business.scale}</p>

    ${!plan ? `
      <div class="card" style="text-align:center;padding:30px">
        <p>${t('loading.financialPlan')}</p>
        <button class="btn btn-primary" id="genPlanBtn" data-id="${business.id}">${t('buttons.financialPlan')}</button>
      </div>` : `
      <div class="grid3" style="margin-bottom:16px">
        ${statCard(t('finance.revenue'), fmtInr(plan.projection.revenue))}
        ${statCard(t('finance.profit'), fmtInr(plan.projection.profit))}
        ${statCard(t('finance.margin'), plan.projection.margin.toFixed(1) + '%')}
      </div>
      <div class="grid2" style="margin-bottom:16px">
        <div class="card">
          <h3 style="margin-top:0">${t('finance.totalCost')}</h3>
          <table style="width:100%;font-size:14px;border-collapse:collapse">
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.investment')}</td><td style="text-align:right">${fmtInr(plan.structure.fixedInvestment)}</td></tr>
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.workingCapital')}</td><td style="text-align:right">${fmtInr(plan.structure.workingCapital)}</td></tr>
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.buffer')}</td><td style="text-align:right">${fmtInr(plan.structure.buffer)}</td></tr>
            <tr style="border-top:1px solid var(--border);font-weight:700"><td style="padding:6px 0">${t('finance.totalCost')}</td><td style="text-align:right">${fmtInr(plan.structure.total)}</td></tr>
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.ownContribution')}</td><td style="text-align:right">${fmtInr(plan.structure.ownContribution)}</td></tr>
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.loanNeeded')}</td><td style="text-align:right">${fmtInr(plan.structure.loanNeeded)}</td></tr>
          </table>
        </div>
        <div class="card">
          <h3 style="margin-top:0">${t('finance.affordability')} ${riskBadgeFor(plan.affordability.level)}</h3>
          <p style="font-size:13.5px;color:var(--text-mute)">${affordDetailFor(plan.affordability.level)}</p>
          <table style="width:100%;font-size:14px;border-collapse:collapse">
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.emi')}</td><td style="text-align:right">${fmtInr(plan.affordability.emi)}</td></tr>
            <tr><td style="color:var(--text-mute);padding:4px 0">${t('finance.roi')}</td><td style="text-align:right">${(plan.returns.roi||0).toFixed(1)}%</td></tr>
          </table>
          <p style="font-size:11.5px;color:var(--text-mute);margin-top:10px">${t('finance.affordability.disclaimer')}</p>
        </div>
      </div>
      <div class="grid2">
        <div class="card">
          <h3 style="margin-top:0">${t('scenarios.title')}</h3>
          <button class="btn btn-dark btn-sm" id="stressBtn" data-plan="${plan.id}">${t('scenarios.runStressTest')}</button>
          <div id="stressResult" style="margin-top:12px"></div>
        </div>
        <div class="card">
          <h3 style="margin-top:0">${t('business.schemes')}</h3>
          <button class="btn btn-dark btn-sm" id="schemesBtn" data-biz="${business.id}">${t('buttons.schemes')}</button>
          <div id="schemesResult" style="margin-top:12px"></div>
        </div>
      </div>
    `}
  </div>`;
}

async function chatView() {
  let conversations = [];
  try { conversations = (await api("/chat/conversations")).conversations; } catch (e) {}
  return `
  <div class="container" style="padding:30px 0">
    <h1 class="serif" style="margin-bottom:4px">${t('chat.title')}</h1>
    <div class="grid2" style="grid-template-columns:220px 1fr;gap:16px;margin-top:16px;align-items:start">
      <div class="card" style="padding:10px">
        <button class="btn btn-primary btn-sm" id="newConvBtn" style="width:100%;margin-bottom:8px">+ ${t('chat.newConversation')}</button>
        <div id="convList" style="display:flex;flex-direction:column;gap:4px">
          ${conversations.map(c => `<button class="btn-ghost btn-sm conv-item" data-id="${c.id}" style="text-align:left;border:none;background:transparent;padding:8px 10px;border-radius:8px">${c.title}</button>`).join("")}
        </div>
      </div>
      <div class="card" style="display:flex;flex-direction:column;height:520px;padding:14px">
        <div id="chatMessages" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding:4px"></div>
        <form id="chatForm" style="display:flex;gap:8px;margin-top:10px">
          <button type="button" id="micBtn" class="btn btn-ghost" title="${t('chat.speak')}">🎙️</button>
          <input class="input" id="chatInput" placeholder="${t('chat.placeholder')}" autocomplete="off">
          <button class="btn btn-primary" type="submit">${t('chat.send')}</button>
        </form>
        <div id="voiceStatus" style="font-size:12px;color:var(--text-mute);margin-top:4px"></div>
      </div>
    </div>
  </div>`;
}

async function schemesView() {
  const { schemes } = await api("/schemes").catch(() => ({ schemes: [] }));
  return `
  <div class="container" style="padding:36px 0">
    <h1 class="serif">${t('nav.schemes')}</h1>
    <p style="color:var(--text-mute);font-size:13.5px">${t('schemes.disclaimer')}</p>
    <div class="grid2" style="margin-top:16px">
      ${schemes.map(s => `
        <div class="card">
          <strong>${s.name}</strong>
          <p style="color:var(--text-mute);font-size:13.5px;margin:6px 0">${s.purpose}</p>
          <p style="font-size:12.5px;color:var(--text-mute)"><b>${s.route}</b></p>
        </div>`).join("")}
    </div>
  </div>`;
}

async function profileView() {
  let profile = {}, financial = {};
  try { const d = await api("/profile"); profile = d.profile || {}; financial = d.financial || {}; } catch (e) {}
  const locs = state.catalog.locations, res = state.catalog.resources;
  return `
  <div class="container" style="padding:36px 0;max-width:640px">
    <h1 class="serif">${t('profile.title')}</h1>
    <div class="card" style="margin-bottom:16px">
      <h3 style="margin-top:0">${t('profile.personalDetails')}</h3>
      <p><b>${state.user.name}</b><br><span style="color:var(--text-mute)">${state.user.email}</span></p>
    </div>
    <form id="profileForm" class="card" style="display:flex;flex-direction:column;gap:14px;margin-bottom:16px">
      <h3 style="margin:0">${t('onboarding.title')}</h3>
      <div><label>${t('onboarding.location')}</label>
        <select class="input" name="locId">
          <option value="">—</option>
          ${locs.map(l => `<option value="${l.id}" ${profile.loc_id === l.id ? 'selected' : ''}>${l.village}, ${l.district}</option>`).join("")}
        </select>
      </div>
      <div><label>${t('onboarding.occupation')}</label><input class="input" name="occupation" value="${profile.occupation || ''}"></div>
      <div><label>${t('onboarding.resources')}</label>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          ${res.map(r => `<label style="display:flex;align-items:center;gap:5px;font-weight:400;font-size:13px;border:1px solid var(--border);padding:5px 9px;border-radius:8px">
            <input type="checkbox" name="resources" value="${r.id}" ${(profile.resources||[]).includes(r.id) ? 'checked' : ''}> ${r.icon} ${r.label}</label>`).join("")}
        </div>
      </div>
      <button class="btn btn-primary" type="submit">${t('buttons.save')}</button>
    </form>
    <form id="financialForm" class="card" style="display:flex;flex-direction:column;gap:14px">
      <h3 style="margin:0">${t('business.money')}</h3>
      <div><label>${t('onboarding.capital')}</label><input class="input" type="number" name="capital" value="${financial.capital || ''}"></div>
      <div><label>${t('finance.expenses')}</label><input class="input" type="number" name="monthlyExpenses" value="${financial.monthly_expenses || ''}"></div>
      <div><label>${t('finance.emi')} (existing)</label><input class="input" type="number" name="existingEmi" value="${financial.existing_emi || ''}"></div>
      <button class="btn btn-primary" type="submit">${t('buttons.save')}</button>
    </form>
  </div>`;
}

async function adminView() {
  let overview = {}, users = [];
  try {
    overview = await api("/admin/overview");
    users = (await api("/admin/users")).users;
  } catch (e) { toast(e.message, true); }
  return `
  <div class="container" style="padding:36px 0">
    <h1 class="serif">${t('admin.title')}</h1>
    <div class="grid3" style="margin-bottom:20px">
      ${statCard(t('admin.users'), overview.users ? overview.users.total : '—')}
      ${statCard(t('admin.businesses'), overview.businesses ? overview.businesses.total : '—')}
      ${statCard(t('admin.aiUsage'), overview.aiUsage ? overview.aiUsage.mode : '—')}
    </div>
    <div class="card">
      <h3 style="margin-top:0">${t('admin.users')}</h3>
      <table style="width:100%;font-size:13.5px;border-collapse:collapse">
        <tr style="text-align:left;color:var(--text-mute)"><th style="padding:6px 0">Name</th><th>Email</th><th>Role</th><th>Lang</th><th>Status</th></tr>
        ${users.map(u => `<tr style="border-top:1px solid var(--border)">
          <td style="padding:6px 0">${u.name}</td><td>${u.email}</td><td>${u.role}</td><td>${u.language}</td>
          <td>${u.is_active ? '<span class="badge badge-ok">active</span>' : '<span class="badge badge-bad">disabled</span>'}</td>
        </tr>`).join("")}
      </table>
    </div>
  </div>`;
}

/* ---------------- render + event wiring ---------------- */
async function render() {
  const hash = location.hash || "#/";
  const app = document.getElementById("app");
  const authed = !!state.token;

  const protectedRoutes = ["#/dashboard", "#/business", "#/chat", "#/schemes", "#/profile", "#/admin"];
  if (!authed && protectedRoutes.some(r => hash.startsWith(r))) {
    app.innerHTML = shell(authView("login")); wireLayout(); wireAuthForm("login"); return;
  }

  if (hash === "#/") { app.innerHTML = shell(landingView()); wireLayout(); return; }
  if (hash === "#/demo") { app.innerHTML = shell(demoView()); wireLayout(); wireDemo(); return; }
  if (hash === "#/login") { app.innerHTML = shell(authView("login")); wireLayout(); wireAuthForm("login"); return; }
  if (hash === "#/signup") { app.innerHTML = shell(authView("signup")); wireLayout(); wireAuthForm("signup"); return; }

  if (hash === "#/dashboard") { app.innerHTML = shell(`<div class="container" style="padding:40px 0"><div class="skel" style="height:120px"></div></div>`); wireLayout(); app.innerHTML = shell(await dashboardView()); wireLayout(); return; }
  if (hash === "#/business") { app.innerHTML = shell(await businessListView()); wireLayout(); return; }
  if (hash === "#/business/new") { app.innerHTML = shell(businessNewView()); wireLayout(); wireBizForm(); return; }
  if (hash.startsWith("#/business/")) {
    const id = hash.split("/")[2];
    app.innerHTML = shell(await businessDetailView(id)); wireLayout(); wireBizDetail(); return;
  }
  if (hash === "#/chat") { app.innerHTML = shell(await chatView()); wireLayout(); wireChat(); wireVoice(); return; }
  if (hash === "#/schemes") { app.innerHTML = shell(await schemesView()); wireLayout(); return; }
  if (hash === "#/profile") { app.innerHTML = shell(await profileView()); wireLayout(); wireProfile(); return; }
  if (hash === "#/admin") {
    if (!state.user || state.user.role !== "admin") { app.innerHTML = shell(`<div class="container" style="padding:40px 0">${t('errors.generic')}</div>`); wireLayout(); return; }
    app.innerHTML = shell(await adminView()); wireLayout(); return;
  }
  app.innerHTML = shell(`<div class="container" style="padding:60px 0;text-align:center">404</div>`); wireLayout();
}

function wireDemo() {
  document.querySelectorAll(".demo-login-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      try {
        const { token, user } = await api("/auth/login", { method: "POST", body: { email: btn.dataset.email, password: "Demo@123" } });
        saveSession(token, user);
        await setLang(user.language);
        location.hash = "#/dashboard";
      } catch (e) { toast(e.message, true); }
    });
  });
}

function wireAuthForm(mode) {
  const form = document.getElementById("authForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const body = Object.fromEntries(fd.entries());
    try {
      const path = mode === "login" ? "/auth/login" : "/auth/signup";
      if (mode === "signup") body.language = state.lang;
      const { token, user } = await api(path, { method: "POST", body });
      saveSession(token, user);
      toast(mode === "login" ? "Welcome back!" : "Account created!");
      location.hash = "#/dashboard";
    } catch (e) { toast(e.message, true); }
  });
}

function wireBizForm() {
  const form = document.getElementById("bizForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const capital = fd.get("capital");
    try {
      if (capital) await api("/profile/financial", { method: "PUT", body: { capital: Number(capital) } });
      const { business } = await api("/businesses", { method: "POST", body: {
        name: fd.get("name"), bizCatalogId: fd.get("bizCatalogId"), locId: fd.get("locId") || undefined, scale: fd.get("scale")
      } });
      await api(`/businesses/${business.id}/plan`, { method: "POST" });
      toast(t("buttons.save"));
      location.hash = `#/business/${business.id}`;
    } catch (e) { toast(e.message, true); }
  });
}

function wireBizDetail() {
  const gen = document.getElementById("genPlanBtn");
  if (gen) gen.addEventListener("click", async () => {
    try { await api(`/businesses/${gen.dataset.id}/plan`, { method: "POST" }); render(); } catch (e) { toast(e.message, true); }
  });
  const stressBtn = document.getElementById("stressBtn");
  if (stressBtn) stressBtn.addEventListener("click", async () => {
    const box = document.getElementById("stressResult");
    box.innerHTML = `<span class="skel" style="display:block;height:60px"></span>`;
    try {
      const { result } = await api(`/scenarios/plan/${stressBtn.dataset.plan}/stress-test`);
      box.innerHTML = `<p style="font-weight:700;margin:0 0 6px">${result.grade}</p>
        ${result.results.map(r => `<div style="display:flex;justify-content:space-between;font-size:13px;padding:3px 0">
          <span>${r.label}</span><span class="badge ${r.verdict === 'ok' ? 'badge-ok' : r.verdict === 'mid' ? 'badge-mid' : 'badge-bad'}">${fmtInr(r.net)}</span></div>`).join("")}`;
    } catch (e) { toast(e.message, true); }
  });
  const schemesBtn = document.getElementById("schemesBtn");
  if (schemesBtn) schemesBtn.addEventListener("click", async () => {
    const box = document.getElementById("schemesResult");
    box.innerHTML = `<span class="skel" style="display:block;height:60px"></span>`;
    try {
      const { matches } = await api(`/schemes/for-business/${schemesBtn.dataset.biz}`);
      const top = matches.filter(m => m.level !== "not_a_strong_match").slice(0, 4);
      box.innerHTML = top.length ? top.map(m => `<div style="padding:8px 0;border-top:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between"><strong style="font-size:13.5px">${m.name}</strong>
        <span class="badge ${m.level === 'highly_relevant' ? 'badge-ok' : 'badge-mid'}">${m.level === 'highly_relevant' ? t('schemes.highlyRelevant') : t('schemes.potentiallyRelevant')}</span></div>
        <p style="font-size:12px;color:var(--text-mute);margin:4px 0 0">${m.reason}</p></div>`).join("")
        : `<p style="color:var(--text-mute);font-size:13px">${t('schemes.notStrongMatch')}</p>`;
    } catch (e) { toast(e.message, true); }
  });
}

let currentConvId = null;
function wireChat() {
  const newBtn = document.getElementById("newConvBtn");
  const input = document.getElementById("chatInput");
  const messages = document.getElementById("chatMessages");
  const form = document.getElementById("chatForm");

  async function openConv(id) {
    currentConvId = id;
    const { messages: msgs } = await api(`/chat/conversations/${id}/messages`);
    messages.innerHTML = msgs.map(bubbleFor).join("") || `<p style="color:var(--text-mute);text-align:center;margin:auto">${t('chat.title')}</p>`;
    messages.scrollTop = messages.scrollHeight;
  }
  function bubbleFor(m) {
    return `<div class="chat-bubble ${m.role === 'user' ? 'chat-user' : 'chat-ai'}">${escapeHtml(m.content)}</div>`;
  }

  newBtn.addEventListener("click", async () => {
    const { conversation } = await api("/chat/conversations", { method: "POST" });
    render();
  });
  document.querySelectorAll(".conv-item").forEach(btn => btn.addEventListener("click", () => openConv(btn.dataset.id)));

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    if (!currentConvId) {
      const { conversation } = await api("/chat/conversations", { method: "POST" });
      currentConvId = conversation.id;
    }
    messages.innerHTML += `<div class="chat-bubble chat-user">${escapeHtml(text)}</div>`;
    input.value = "";
    const thinkingEl = document.createElement("div");
    thinkingEl.className = "chat-bubble chat-ai";
    thinkingEl.innerHTML = `<span class="spin" style="border-top-color:var(--forest);border-color:rgba(47,59,47,.3)"></span> ${t('chat.thinking')}`;
    messages.appendChild(thinkingEl);
    messages.scrollTop = messages.scrollHeight;
    try {
      const { reply } = await api(`/chat/conversations/${currentConvId}/messages`, { method: "POST", body: { message: text } });
      thinkingEl.textContent = reply;
      speak(reply, state.lang);
    } catch (e) {
      thinkingEl.textContent = t("errors.aiUnavailable");
    }
    messages.scrollTop = messages.scrollHeight;
  });
}
function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

/* ---------------- voice (real browser Web Speech API — STT + TTS) ---------------- */
const VOICE_LANG = { en: "en-IN", hi: "hi-IN", hinglish: "hi-IN" };
function wireVoice() {
  const micBtn = document.getElementById("micBtn");
  const status = document.getElementById("voiceStatus");
  const input = document.getElementById("chatInput");
  if (!micBtn) return;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    micBtn.disabled = true;
    micBtn.title = t("chat.typeInstead");
    status.textContent = t("chat.typeInstead") + " (voice not supported in this browser)";
    return;
  }
  const recog = new SR();
  recog.lang = VOICE_LANG[state.lang] || "en-IN";
  recog.interimResults = false;
  recog.maxAlternatives = 1;
  let listening = false;

  micBtn.addEventListener("click", () => {
    if (listening) { recog.stop(); return; }
    recog.lang = VOICE_LANG[state.lang] || "en-IN";
    try { recog.start(); } catch { return; }
  });
  recog.addEventListener("start", () => { listening = true; status.textContent = t("chat.listening"); micBtn.style.background = "var(--terracotta)"; micBtn.style.color = "#fff"; });
  recog.addEventListener("end", () => { listening = false; status.textContent = ""; micBtn.style.background = ""; micBtn.style.color = ""; });
  recog.addEventListener("error", () => { listening = false; status.textContent = t("errors.generic"); micBtn.style.background = ""; micBtn.style.color = ""; });
  recog.addEventListener("result", (e) => {
    status.textContent = t("chat.understanding");
    const text = e.results[0][0].transcript;
    input.value = text;
    document.getElementById("chatForm").requestSubmit();
  });
}
function speak(text, lang) {
  if (!("speechSynthesis" in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.lang = VOICE_LANG[lang] || "en-IN";
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(u);
}

function wireProfile() {
  const pf = document.getElementById("profileForm");
  pf.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(pf);
    const resources = fd.getAll("resources");
    try {
      await api("/profile", { method: "PUT", body: { locId: fd.get("locId") || undefined, occupation: fd.get("occupation") || undefined, resources } });
      toast(t("buttons.save"));
    } catch (e) { toast(e.message, true); }
  });
  const ff = document.getElementById("financialForm");
  ff.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(ff);
    try {
      await api("/profile/financial", { method: "PUT", body: {
        capital: Number(fd.get("capital")) || undefined,
        monthlyExpenses: Number(fd.get("monthlyExpenses")) || undefined,
        existingEmi: Number(fd.get("existingEmi")) || undefined
      }});
      toast(t("buttons.save"));
    } catch (e) { toast(e.message, true); }
  });
}
