import { createContext, useContext, useEffect, useState, useCallback } from "react";
import authApi from "../services/authApi";
import { getToken, setToken } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // restoring session on load
  const [error, setError] = useState(null);

  // Restore session from stored JWT on first load
  useEffect(() => {
    async function restore() {
      const token = getToken();
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const data = await authApi.me();
        setUser(data.user);
      } catch {
        setToken(null);
        setUser(null);
      } finally {
        setLoading(false);
      }
    }
    restore();
  }, []);

  const signup = useCallback(async (payload) => {
    setError(null);
    const data = await authApi.signup(payload);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const login = useCallback(async (payload) => {
    setError(null);
    const data = await authApi.login(payload);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  const setLanguagePreference = useCallback(async (language) => {
    await authApi.setLanguage(language);
    setUser((u) => (u ? { ...u, language } : u));
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        loading,
        error,
        setError,
        signup,
        login,
        logout,
        setLanguagePreference,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}

export default AuthContext;
