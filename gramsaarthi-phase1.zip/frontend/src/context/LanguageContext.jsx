import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import en from "../i18n/en.json";
import hi from "../i18n/hi.json";
import hinglish from "../i18n/hinglish.json";
import { useAuth } from "./AuthContext";

const DICTS = { en, hi, hinglish };
const STORAGE_KEY = "gramsaarthi_language";
const SUPPORTED = ["en", "hi", "hinglish"];

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const { user, setLanguagePreference } = useAuth();

  const [language, setLanguageState] = useState(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return SUPPORTED.includes(stored) ? stored : "en";
  });

  // When a logged-in user's stored language preference arrives, adopt it.
  useEffect(() => {
    if (user?.language && SUPPORTED.includes(user.language) && user.language !== language) {
      setLanguageState(user.language);
      localStorage.setItem(STORAGE_KEY, user.language);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.language]);

  const setLanguage = useCallback(
    async (next) => {
      if (!SUPPORTED.includes(next)) return;
      setLanguageState(next);
      localStorage.setItem(STORAGE_KEY, next);
      if (user) {
        try {
          await setLanguagePreference(next);
        } catch {
          // Non-fatal: UI still switches even if persisting the preference fails.
        }
      }
    },
    [user, setLanguagePreference]
  );

  const dict = DICTS[language] || DICTS.en;

  const t = useCallback(
    (key, vars) => {
      let str = dict[key] ?? DICTS.en[key] ?? key;
      if (vars) {
        Object.entries(vars).forEach(([k, v]) => {
          str = str.replace(new RegExp(`{${k}}`, "g"), v);
        });
      }
      return str;
    },
    [dict]
  );

  const value = useMemo(
    () => ({ language, setLanguage, t, supported: SUPPORTED }),
    [language, setLanguage, t]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within a LanguageProvider");
  return ctx;
}

export default LanguageContext;
