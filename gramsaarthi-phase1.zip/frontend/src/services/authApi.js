import api from "./api";

export const authApi = {
  signup: (payload) => api.post("/auth/signup", payload, { auth: false }),
  login: (payload) => api.post("/auth/login", payload, { auth: false }),
  me: () => api.get("/auth/me"),
  setLanguage: (language) => api.post("/auth/language", { language }),
};

export default authApi;
