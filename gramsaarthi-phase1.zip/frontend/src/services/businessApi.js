import api from "./api";

export const businessApi = {
  list: () => api.get("/businesses"),
  create: (payload) => api.post("/businesses", payload),
  get: (id) => api.get(`/businesses/${id}`),
  remove: (id) => api.delete(`/businesses/${id}`),
  createPlan: (id, payload) => api.post(`/businesses/${id}/plan`, payload),
  listPlans: (id) => api.get(`/businesses/${id}/plans`),
  deletePlan: (id, planId) => api.delete(`/businesses/${id}/plans/${planId}`),
  recommend: () => api.get("/businesses/recommend/for-me"),
};

export const catalogApi = {
  businesses: () => api.get("/catalog/businesses", { auth: false }),
  locations: () => api.get("/catalog/locations", { auth: false }),
  resources: () => api.get("/catalog/resources", { auth: false }),
  states: () => api.get("/catalog/states", { auth: false }),
};

export const financialApi = {
  emi: (payload) => api.post("/financial/emi", payload),
};

export const scenarioApi = {
  listForPlan: (planId) => api.get(`/scenarios/plan/${planId}`),
  createForPlan: (planId, payload) => api.post(`/scenarios/plan/${planId}`, payload),
  stressTest: (planId) => api.get(`/scenarios/plan/${planId}/stress-test`),
  remove: (id) => api.delete(`/scenarios/${id}`),
};

export const schemeApi = {
  list: () => api.get("/schemes", { auth: false }),
  forBusiness: (businessId) => api.get(`/schemes/for-business/${businessId}`),
};

export const chatApi = {
  listConversations: () => api.get("/chat/conversations"),
  createConversation: (payload) => api.post("/chat/conversations", payload),
  renameConversation: (id, title) => api.put(`/chat/conversations/${id}`, { title }),
  deleteConversation: (id) => api.delete(`/chat/conversations/${id}`),
  listMessages: (id) => api.get(`/chat/conversations/${id}/messages`),
  sendMessage: (id, content) => api.post(`/chat/conversations/${id}/messages`, { content }),
};

export const profileApi = {
  get: () => api.get("/profile"),
  update: (payload) => api.put("/profile", payload),
  updateFinancial: (payload) => api.put("/profile/financial", payload),
};

export const notificationApi = {
  list: () => api.get("/notifications"),
  markRead: (id) => api.post(`/notifications/${id}/read`),
};

export const adminApi = {
  overview: () => api.get("/admin/overview"),
  users: () => api.get("/admin/users"),
  user: (id) => api.get(`/admin/users/${id}`),
  disableUser: (id) => api.post(`/admin/users/${id}/disable`),
  enableUser: (id) => api.post(`/admin/users/${id}/enable`),
  businesses: () => api.get("/admin/businesses"),
  auditLogs: () => api.get("/admin/audit-logs"),
};
