import { useState } from "react";
import { Eye, EyeOff, ArrowRight, UserPlus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ApiError } from "../services/api";

const LANGUAGE_OPTIONS = [
  { value: "en", label: "English" },
  { value: "hi", label: "हिन्दी (Hindi)" },
  { value: "hinglish", label: "Hinglish" },
];

export default function Register() {
  const navigate = useNavigate();
  const { signup } = useAuth();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    language: "en",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);

    if (form.password !== form.confirmPassword) {
      setFormError("Passwords do not match.");
      return;
    }

    setSubmitting(true);
    try {
      await signup({
        name: form.name,
        email: form.email,
        password: form.password,
        language: form.language,
      });
      navigate("/onboarding");
    } catch (err) {
      setFormError(
        err instanceof ApiError ? err.message : "Something went wrong. Please try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="register-page">

      {/* Left Information */}
      <div className="register-info">

        <div className="register-brand">
          <span>🌾</span>
          <div>
            <h2>Gram-Pragati AI</h2>
            <p>Business Partner for Rural India</p>
          </div>
        </div>

        <div className="register-content">
          <h1>
            Start your<br />
            business journey.
          </h1>

          <p>
            Get practical AI-powered guidance to discover
            business opportunities, plan your finances and
            grow your rural business.
          </p>

          <div className="register-features">
            <div>🌱 Discover suitable business ideas</div>
            <div>📊 Understand local demand</div>
            <div>💰 Plan your money safely</div>
            <div>🏛️ Find relevant government schemes</div>
          </div>
        </div>

        <div className="register-bottom">
          Made for Rural India 🇮🇳
        </div>

      </div>

      {/* Form */}
      <div className="register-section">

        <div className="register-card">

          <div className="mobile-register-logo">
            🌾 Gram-Pragati AI
          </div>

          <div className="register-heading">
            <div className="register-icon">
              <UserPlus size={25} />
            </div>

            <h1>Create your account</h1>

            <p>
              Join Gram-Pragati AI and start building your
              business journey.
            </p>
          </div>

          <form onSubmit={handleSubmit}>

            {formError && (
              <div className="form-error" role="alert" style={{ color: "#b3261e", marginBottom: "12px" }}>
                {formError}
              </div>
            )}

            {/* Name */}
            <div className="form-group">
              <label>Full Name</label>

              <input
                type="text"
                name="name"
                placeholder="Enter your full name"
                value={form.name}
                onChange={handleChange}
                required
                minLength={2}
              />
            </div>

            {/* Email */}
            <div className="form-group">
              <label>Email</label>

              <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>

            {/* Password */}
            <div className="form-group">
              <label>Password</label>

              <div className="password-input">

                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  placeholder="Create a password (min. 6 characters)"
                  value={form.password}
                  onChange={handleChange}
                  required
                  minLength={6}
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowPassword(!showPassword)
                  }
                >
                  {showPassword ? (
                    <EyeOff size={20} />
                  ) : (
                    <Eye size={20} />
                  )}
                </button>

              </div>
            </div>

            {/* Confirm Password */}
            <div className="form-group">
              <label>Confirm Password</label>

              <div className="password-input">

                <input
                  type={showConfirm ? "text" : "password"}
                  name="confirmPassword"
                  placeholder="Confirm your password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  required
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowConfirm(!showConfirm)
                  }
                >
                  {showConfirm ? (
                    <EyeOff size={20} />
                  ) : (
                    <Eye size={20} />
                  )}
                </button>

              </div>
            </div>

            {/* Language */}
            <div className="form-group">
              <label>Preferred Language</label>

              <select
                name="language"
                value={form.language}
                onChange={handleChange}
              >
                {LANGUAGE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Terms */}
            <label className="terms">
              <input type="checkbox" required />

              <span>
                I agree to the Terms of Service and
                Privacy Policy.
              </span>
            </label>

            <button
              type="submit"
              className="login-button"
              disabled={submitting}
            >
              {submitting ? "Creating account…" : "Create Account"}
              <ArrowRight size={19} />
            </button>

          </form>

          <div className="register-text">
            Already have an account?

            <Link to="/login">
              {" "}Login
            </Link>
          </div>

        </div>

      </div>

    </div>
  );
}
